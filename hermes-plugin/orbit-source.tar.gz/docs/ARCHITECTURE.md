# Architecture

## Connected surface rendering

Pane views are keyed by stable pane IDs, with kind and browser URL determining
runtime replacement. Layout reconciliation creates connected slots and parks
surviving views in a connected host before removing old containers; native
`Element.moveBefore` preserves iframe document state during same-document moves.
Anchors are connected before accepting existing views and are pruned even
when a view is not currently displayed. The non-native fallback warns and **does not guarantee iframe
continuity**. Explicit imports/presets intentionally replace views; checkpoints
cannot resurrect a disposed document. See [runtime continuity](RUNTIME_CONTINUITY.md)
for measured coverage and [docking evaluation](DOCKING_EVALUATION.md) for candidate
research, not a selected replacement framework.

Test servers can set `ORBIT_TMUX_SOCKET` to a validated private socket name and
`ORBIT_TMUX_CONFIG=/dev/null` to avoid loading personal tmux configuration. History
capture uses the same socket as the provider. Defaults remain `orbit-persistent`
and normal tmux configuration; these settings do not isolate an entire host.

Orbit is a single-owner agent-customizable workspace. It separates trusted core/integration code from sandboxed generated app plugins; it is not fully modular yet.

The earlier docking spike (an isolated opt-in fixture) was removed in the rizzstack
cleanup; product docking is `src/docking-*.ts`, and the spike survives only in git
history before the cleanup. `server/terminal-resource-registry.mjs` is a process-local
identity primitive used by the managed-terminal broker, not itself a grant service or tmux adapter. See
[docking spike](ORBIT_DOCKING_SPIKE.md) and [registry](TERMINAL_RESOURCE_REGISTRY.md)
for the historical spike evidence and current identity boundaries.

`?renderer=docking` now explicitly opts the normal frontend into experimental
Dockview placement (`src/docking-renderer.ts`, exact `dockview-core@8.3.1`). The
default renderer remains unchanged. Existing PaneViews, workspace sync and recovery
remain authoritative; durable tabs/floats use a separate validated placement-v1
adjunct in SQLite schema 4, never fields in the v1 layout. Library/styles
load dynamically only on opt-in. See [optional docking](OPTIONAL_DOCKING.md).

`server/managed-terminal-provider.mjs` supports explicit adoption of existing Linux
tmux shells through the owner-only managed-terminal routes and pane controls.
Private fresh-session mode remains an internal provider component. Durable private
identity metadata is separate from process-local, expiring consent grants; neither
terminal buffers nor grants enter layout checkpoints. Its ownership/cleanup and
kernel-identity limitations are documented in [managed terminals](MANAGED_TERMINALS.md).

## State and control

`src/model.ts` validates layout, structured appearance and plugin instances. `src/workspace-ops.ts` applies targeted operations to a clone; `src/plugins.ts` implements plugin lifecycle. The service in `server/workspace.mjs` authenticates browser requests with Orbit token/origin checks, and agent requests with a workspace-scoped capability. Strict request schemas precede semantic checks. `SqliteWorkspaceStore` atomically commits state/revision, applicable checkpoints, keyed command receipts and metadata outbox rows in `.runtime/workspace.sqlite`. Existing JSON runtimes require an explicit offline migration; originals remain archived, never a writable fallback. Private `workspace-access` files are credential/API discovery projections only. The serialized layout remains v1; there is no normalized surface migration yet. See [Workspace store](WORKSPACE_STORE.md).

`src/workspace-sync.ts` polls and tracks browser acknowledgement. An acknowledged revision does not prove a widget rendered correctly. Local layout persistence and imports remain supported. Offline changes can be saved server-side; display acknowledgement waits for the browser.

The default shell's `src/workspace-arrange.ts` uses owner-only `layout_preview` /
`layout_apply` commands for existing-window placement. Their contract is a restricted operation union, not general
controller access: no creation/removal, plugin mutation or whole-state replacement.
Apply requires an operation identity and current base revision. Checkpoint
`checkpoint_preview` returns a bounded metadata diff through
`server/workspace-diff.mjs`; it does not mutate, render or promise successful restore.

`server/workspace-description.mjs` provides authenticated, bounded layout metadata
and an opt-in operation catalog sourced directly from the workspace contract.
Normal's workspace adapter can discover this catalog rather than embedding every
operation in its prompt. No project bindings are exposed after the Phase 3
removal; neither role nor pane selection authorizes access to resource content.
Project paths, credentials, terminal output and conversation content are omitted.
This owner/controller interface is not exposed to generated frames. The
implementation ledger is
[Environment malleability](ENVIRONMENT_MALLEABILITY_LEDGER.md).

Schema 3 adds an indexed bundle registry and workspace-scoped metadata event queries.
Schema 4 adds transactional docking placement, revision/checkpoint copies, and
shared workspace-revision CAS. Schema-3 databases upgrade on opening; owner
runtimes must be backed up and tested in a separate copy before upgrade.
Project Workbench was removed in cleanup Phase 3 with its `wb_*` and project-tool
tables left inert in the database and no schema-version change. Schema 5 added
separate project/resource/surface-binding records and schema 6 added private
task, attempt, context, disclosure, submission, candidate, job, evidence and
review records; those tables remain unused.

Normal chat may overlap independently receipted accepted conversations. Its trusted
adapter caller supplies a cross-conversation admission predicate that validates
the other run's private receipt, binding and current profile fingerprint; this
predicate is never accepted from a browser or model request. Unknown or
unresolved submissions retain global exclusion. Preparation/dispatch is
durable, while active Normal runs remain recoverable after restart. Same-session
and unknown-outcome fences remain separate from background UI synchronization.
Schemas 7 and 8 added the remaining private Phase 3 tables; they stay inert.
Normal reads use indexed asset versions; startup/admin publication refresh performs
filesystem scanning. Hash-addressed asset responses verify indexed bytes before serving.
Retention plans include all saved revisions/checkpoints and are dry-run only.
`server/workspace-events.mjs` provides authenticated bounded POST event pages, not SSE;
`src/workspace-events.ts` keeps an in-memory reconnect cursor and triggers coalesced
state reads. Ordinary polling remains the fallback. Neither events nor acknowledgement
prove rendering, and no credentials or terminal/conversation content belong in events.

The owner-only recovery console can persist a registered-plugin activation hold
outside checkpoint state. Policy generation and candidate-state checks share the
command transaction. Entering hold disables plugins and trusted project-tool
instances; release never auto-enables them.
Receipts from older policy generations fail closed rather than replaying an obsolete
activation snapshot. This does not stop cached/offline frames or external backends,
block public app files, or implement general safe boot. See [Recovery](RECOVERY.md).

## Two extension boundaries

### Cross-surface content and recovery

Trusted complete-result adapters offer explicit owner actions for A2UI, document
drafts and self-contained MCP snapshots. They do not reinterpret cached transcripts
as authenticated results. A2UI queues are bounded to a chosen workspace/pane/mount
generation; queueing, rendering and saving have separate acknowledgements.
`src/conversation-transfer.ts` prepares an exact final recipient draft and validates
producer/recipient freshness at insertion. Citations and bounded selected data
values travel in actual content, not only preview labels; insertion never sends.

Documents retain separate original-pane drafts with a same-tab recovery index and
host-owned dirty-close review. Whole-snapshot edit proposals bind saved revision
and draft digest and apply through native editor history. The document store's
atomic `create_content` operation is distinct from owner-reviewed draft creation.
Current bodies/receipts are not a historical body archive. See
[Documents](DOCUMENTS.md), [Context handoff](CONTEXT_HANDOFF.md) and
[Resource delegation](RESOURCE_DELEGATION.md) for exact authority and recovery.

Normal resource authority joins actual pinned gateway ContextVars to the exact
accepted Orbit submission receipt, profile fingerprint and pane binding revision.
A private per-run authenticated socket channel carries finite selected-source
operations; grants attach to the next accepted run and do not inherit into later
turns. The source-pinned plugin rejects environment-only/session-only identities
and delegated child contexts. This local adapter is configured explicitly and does
not broaden the ordinary workspace controller or generated-plugin authority.

Trusted built-ins use `src/workspace-extensions.ts`: typed activation entries dynamically load plugin manager, checkpoints, skills catalog, outputs and jobs. Live activity is also loaded on demand. These modules run in the parent page and are reviewed application code. They are not user-installable privileged plugins.

`src/host-surfaces.ts` additionally allowlists the exact browser-pane URLs
`orbit://surface/outputs` and `orbit://surface/activity` for persistent Outputs and
Activity windows. Mounted views dispose subscriptions and requests when their pane
is disposed; movable pane identity and ordinary layout persistence stay in charge.
Credentials come from the live host callback, never the URL. This does not grant a
host bridge to generated frames. Shell discovery uses `src/workspace-commands.ts`
with shared Start/palette command availability and experimental gates.

Generated app plugins use a strict API-v1 manifest and config contract. `scripts/plugin_publish.py` copies static bundles to content-addressed folders. Lifecycle/config/entry references are part of workspace state and checkpoints. The existing sandboxed browser pane hosts the app; no host credentials or privileged message bridge are granted. Network access is allowed by the current app CSP. See [PLUGINS.md](PLUGINS.md) for limitations, including the absence of filesystem-enforced immutability, dependency resolution and independent safe boot.

Optional `configSchema` is bounded declarative metadata for the existing primitive
config map, not arbitrary JSON Schema or code. `src/plugin-config-schema.ts` and
the publisher validate the same finite shape. Multiple stateless widget instances
retain their manifest definition ID and add distinct instance/window/pane IDs;
legacy ID-only operations keep their primary-instance meaning. Definition updates
are app-wide, while configuration/window/lifecycle actions target an instance.
Browser `sync` declares feature support and refuses unsupported old-client
snapshots when the saved workspace contains instances or config schemas. See
[Widget configuration](WIDGET_CONFIGURATION.md) and [Plugins](PLUGINS.md).

Schema 12 is a version-only writer fence for those extended widget records. It
adds no primary workspace tables, preserves existing rows, and prevents schema-11
servers from opening a newer database after cutover. Restoring an older server
requires a compatible pre-upgrade runtime backup; changing only a release pointer
does not downgrade data. See [Workspace store](WORKSPACE_STORE.md).

The output library stores private per-workspace aliases, pins and tags separately
from immutable published files. Metadata keys include the complete content-
addressed URL, so a changed publication cannot inherit another artifact's label.
`src/conversation-transfer.ts` offers an explicit trusted-recipient registry and
preview-before-insert dialog. It delivers to one chosen chat draft; it neither
sends a model request nor creates a generated-frame bridge. See
[Output library](OUTPUT_LIBRARY.md) and [Context handoff](CONTEXT_HANDOFF.md).

Project tools were removed in cleanup Phase 3; their schema-10 tables remain in
the database, inert.

## Local technology surfaces

Reviewed, lazy host surfaces add A2UI interactive results, local voice
dictation, documents/whiteboards and run traces. They use stable browser-kind
pane identities and owner-authenticated APIs;
generated app frames receive no new private-data bridge. Explicit context transfer
still previews text for one selected draft without sending it. Hermes remains the
agent runtime and the workspace store remains the layout transaction authority.

Source snapshots, rich documents, result edits and app snapshots have
private stores independent of layout checkpoints. Search indices are rebuildable;
the ingested snapshots they cite are authoritative. Voice models are explicitly
provisioned with integrity pins. Browser-side engines
load local assets on demand, without global COOP/COEP. See
[technology surfaces](TECHNOLOGY_FEATURES.md) and the feature-specific contracts.

## Exact-artifact Studio

`server/extension-studio.mjs` admits only the finite `focus-timer-v1` generator.
Private immutable file-backed drafts/checks/proposals reference content-addressed
publisher outputs. Installation commits the staged layout/checkpoint and command
receipt together. Revocation uses append-only `studio-revoke` receipts, checked by
every workspace commit before enabling a registered release. Schema 11 is a writer
fence for those semantics; it preserves schema-10 tables and v1 layouts. Generated
frames receive no host/private-data bridge. See [Studio](EXTENSION_STUDIO.md).

## Hermes

Goal-first setup was removed in cleanup Phase 3; its tables remain in the
database, inert.

`server/agent.mjs` bridges authenticated runs, bounded server-loaded conversation history, approvals, stop, steering, activity, capabilities, catalog and job controls. `server/workspace.mjs` supplies the active workspace context and reads `docs/AGENT_GUIDE.md` into it at request time. Editing that guide updates subsequent contexts without copying instructions into several prompts. `src/agent-chat.ts` retains per-pane UI state; Hermes is a real runtime, not a chat stub.

The gateway's tool environment may differ from the terminal host. Local workspace control requires access to the repository/runtime; it is not automatically available to a remote gateway. Layout metadata does not expose terminal buffers or embedded app DOM.

Per-pane Hermes selection uses a server-side profile routing allowlist rather than
changing the gateway's global active profile. Profile/session bindings belong to
private shared-chat state, not layout checkpoints. Browser selectors receive
profile labels and IDs, never gateway keys. See [Hermes setup](HERMES.md) for the
configuration contract and limitations; a selectable profile does not establish
that its tools can access this host or that an externally started run is idle.

## Terminals

An authenticated same-origin `/api/terminal` WebSocket creates a node-pty client. `auth` accepts `token`, `cols`, `rows` and stable `pane_id`. On the verified Linux deployment, `LocalHostProvider` attaches valid pane IDs to `/usr/bin/tmux -L orbit-persistent` session `pane-<id>`. The client can die while the shell survives. Unlock/reconnect after page reload reattaches; `exit` ends the shell. Legacy requests without a valid pane ID still use direct shells. Host reboot persistence is not implemented.

Transport retains input/resize/data/ack/exit/error messages, bounded output, heartbeat and backpressure. ACK uses JavaScript UTF-16 string length after xterm consumes output. Killing a tmux client is not killing the detached shell. Detached sessions consume resources and require owner cleanup. This is one OS user's workspace, not per-user process isolation.

## Rendering

Windows mode positions native DOM panes; text, xterm and iframe controls remain native DOM. Stable pane IDs preserve views where possible. Focus mode moves the selected window to a flat layer; iframe reparenting can reload embedded content.

`src/windows.ts`, `src/main.ts` and `src/panes.ts` contain the core renderer/pane coordination. These have not been replaced by plugins. Appearance tokens apply through `src/workspace-appearance.ts`; built stylesheet swapping is separate from plugin lifecycle and does not hot-replace production JavaScript.

## Source map

| Component | Files |
| --- | --- |
| State and operations | `src/model.ts`, `src/workspace-ops.ts`, `src/plugins.ts` |
| Workspace persistence / context | `server/workspace.mjs`, `src/workspace-sync.ts` |
| Checkpoints / recovery policy | `server/sqlite-workspace-store.mjs`, `src/workspace-history.ts`, `public/recovery.js` |
| Trusted extensions | `src/workspace-extensions.ts` |
| Plugin management / publishing | `src/plugin-manager.ts`, `scripts/plugin_publish.py` |
| Agent bridge / UI | `server/agent.mjs`, `src/agent-chat.ts` |
| Host PTYs | `server/local-host.mjs`, `server/index.mjs`, `src/panes.ts` |
| Security | `server/security.mjs`, sandbox headers in `server/workspace.mjs` |
| Agent instructions | `docs/AGENT_GUIDE.md`, `AGENTS.md` |

For operation contracts use [Workspace control](WORKSPACE_CONTROL.md), not architecture prose. For shipped versus proposed scope use [Roadmap](ROADMAP.md).
