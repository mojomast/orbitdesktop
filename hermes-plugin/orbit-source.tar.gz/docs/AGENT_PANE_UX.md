# Agent pane information hierarchy

The agent pane separates **conversation and work**, **contextual activity**, and
**configuration/troubleshooting**. This is a presentation boundary; it does not
change execution authority or the meaning of a recorded outcome.

## Visibility budget

The Workspace arrange dialog applies Grid, Focus and Compare placement to
existing windows and is available from the Docking disclosure. Saved workspace
layouts name a placement preset for those existing windows; exact operations,
revision and viewport live in Advanced details. Apply waits for browser
acknowledgement without calling that visual verification. Reloaded pending
save/apply identities are reconciled explicitly against durable records; opening
the dialog never submits a model request or releases an execution lane. See
[saved workspace layouts](SAVED_WORKSPACE_LAYOUTS.md).

Normal mode keeps the conversation title, one concise runtime status, and an
overflow control in its permanent header. The composer has one primary Send
control and compact secondary actions. Profile and
session binding, rename/color, notification preferences, workspace-agent overview,
healthy submission receipts belong in secondary surfaces.

The conversation action row keeps **New chat**, **History**, and **Show tools**
visible in Normal mode, including narrow panes. History opens the retained
conversations/tools dialog. New chat changes this pane's conversation; it does
not create another workspace window. It preserves the previous conversation and
its separately keyed draft. Missing-history errors also expose an explicit New
chat action beside the error.

Initial host linking is distinct from a passive conversation refresh. Passive
reads never disable Send or New chat; delayed snapshots are discarded after a
foreground operation, even if that operation has already completed. Sends retain
the exact selected profile/session/revision and the backend rejects stale scope.
A read failure shows a connection notice rather than labeling message delivery
failed. Actual work, approvals and unresolved outcomes retain their guards.

Normal chat has a visible **Show tools / Hide tools** toggle below its header.
It restores the existing per-pane preference and exposes the retained tool view
inside the conversation, with bounded scrolling, observed call counts and expanded
arguments/results. **Load saved details** retrieves persisted conversation tools.
The overflow **Saved tools** shortcut opens this same view. Toggling visibility
does not submit a model request or change execution; mode changes retain its DOM.
Only the preference is stored locally, never tool payloads. Gateways without live
call IDs show separate observations rather than invented correlated executions.

The restored inline view is exercised by `tests/agent-pane-ux.browser.py` in both
renderers at four viewport sizes: live SSE observations, saved tool details,
hide/show, reload preference, retained mode-switch DOM and composer drafts. These
fixtures assert that inspection does not submit or approve model work.

Use **Agent pane menu → Conversation settings / Activity / Saved tools /
Troubleshooting**. The activity summary counts retained event observations, not
verified tool executions. An empty event history adds no conversation block.
Ordinary completed runs say **Ready**; raw lifecycle labels remain in
Troubleshooting. A settings-catalog failure marks the menu and retains its detail
in Settings without pretending that a running model failed.

Activity remains subscribed when its Inspector panel is closed. Closing a panel
does not cancel a run, clear a transcript, discard retained events, acknowledge an
unknown result, or release the shared execution lane. An offline activity stream
does not imply that execution has stopped. Successful completion returns to the
quiet Ready presentation; actual approvals and unknown outcomes remain actionable.

Selection is not authorization: all execution and handoff previews still use their
existing server-validated records and immutable context captures. The Review surface
retains the same exact historical
diff component and independent recorder evidence.

Selecting live or retained job output is a view choice independent of whether
tail polling is active. Completion, pause or a read failure must not let a late
initial detail response replace that chosen output. Superseded read responses are
ignored; changing the view never reruns the job or changes its recorded verdict.

Use **Task settings** for project/task selection and the nested candidate,
attempt and result chooser. Exactly one explicitly selected option is a label;
an unselected option still requires a deliberate choice. **Exact scope and runtime
details** retains IDs, hashes and budgets. Authority controls live in **Checks**;
**Task handoff** retains immutable excerpt preview/capture. Changes keeps verified
patch and integration operations in a separate disclosure below the shared diff.
Explicit tab choices persist as visual preferences and suppress automatic tab
changes; they do not persist any running, approved or verified conclusion.

## Interaction boundaries

Secondary panels retain their existing DOM and behavior adapters. Moving a
configuration control does not alter its binding-change guards. Switching modes
does not copy drafts or start inference. Exceptional state cards are driven by
current authenticated state, not persisted visual preferences. Visual choices may
be persisted locally; runtime conclusions must be re-read.

Keyboard users can open the Inspector, select a panel and close it with Escape,
returning focus to the invoking control. On narrow panes, secondary information
uses a dedicated overlay rather than wrapping the permanent header into multiple
configuration rows. Conversation and Inspector have separate scroll regions.

## Verification

Acceptance includes both renderers, preserved authority/workflow regressions, and
visual inspection at desktop and narrow viewport sizes. Fixtures use disposable
workspaces and synthetic states; screenshots and private source stay outside Git.
DOM assertions alone are insufficient: header/composer height, visible message
area, exceptional-state prominence and code-review placement are reviewed visually.

The production-build visual fixture covers Normal idle, running, approval, exact
diff, and unknown execution states across two renderers and four sizes. Earlier
Workbench-specific states were removed in cleanup Phase 3. It uses intercepted synthetic authority responses, with deliberately
offline live-stream fallback in running examples, and never dispatches a model.
Twenty-four additional idle/accessibility cases cover Paper, XP and Classic.

Measured agent header height was 44 px; idle composer height was 82 px by default
and in Paper, 88 px in XP and 72 px in Classic. Conversation occupied 78–91% of
the pane body. These measurements exclude the surrounding desktop/window chrome.
The reconstructed before-state uses the archived `0a93350` source, not an original
owner screenshot. Private before/after images and machine-readable reports are
kept under `/tmp/opencode/orbit-agent-ux-qa`, outside Git.

Real-server regressions separately cover both-renderer mode independence,
immutable context and authority handoff, shared execution fences, historical diffs,
scope clearing, project revocation, result review/placement and reload. The
separate trusted Review window is covered there.

The pane header’s provider menu, the **Sessions** history sidecar, the context
meter, and Compact are specified in [AGENT_CONTEXT.md](AGENT_CONTEXT.md). History
in the conversation action row still opens the tools dialog. Sessions is the
searchable sidecar. Those controls do not start a run by themselves.

Binding invalidation releases the superseded load's busy ownership before
launching its replacement. The accepted chat binding is installed first.
A deterministic delayed-import regression covers this reload interleaving: the
replacement must reconnect retained activity without a manual refresh or replaying
execution. Old asynchronous loads remain fenced by their epoch checks.
