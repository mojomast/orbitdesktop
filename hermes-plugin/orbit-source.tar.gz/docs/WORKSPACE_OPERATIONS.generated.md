# Workspace command contract v1 (generated)

Run `node scripts/generate-workspace-contract.mjs --check` to verify parity.

Authoritative validation: strict JSON Schema plus existing semantic/resource checks. Unknown fields and type coercion are rejected. Request bytes include the full UTF-8 envelope.

- maxOperations: 32
- maxRequestBytes: 150000
- maxResponseBytes: 2000000
- maxLabelCharacters: 120

Mutations with `operation_id`, `intent` and `base_revision` commit durable receipts in SQLite. Identical actor/workspace/key/payload retries return the original result while recovery policy generation is unchanged; obsolete-policy replay fails closed rather than returning an unsafe historical activation snapshot. Changed payloads with the same key fail. Legacy missing-key requests receive server-generated IDs and are not retry-safe. Preview remains structural with provisional generated IDs. The layout model remains v1.

| Operation | Required fields (besides action) | Optional fields | Effect |
|---|---|---|---|
| set_spatial_camera | camera |  | layout |
| arrange_spatial |  | window_ids, mode, columns, gap | layout |
| reset_appearance | keys |  | layout |
| set_arc | arc |  | layout |
| reorder_windows | window_ids |  | layout |
| swap_panes | window_id, pane_id, other_window_id, other_pane_id |  | layout |
| layout_panes | window_id, layout |  | layout |
| arrange_windows | width, height | window_ids, columns, gap | layout |
| set_workspace | state |  | layout |
| patch_appearance | patch |  | layout |
| set_appearance | appearance |  | layout |
| update_split | window_id, path | ratio, axis, swap | layout |
| set_view | view |  | layout |
| sidebar | hidden |  | layout |
| select | window_id |  | layout |
| add_window |  | name, kind, url, frame | layout |
| update_window | window_id | name, diagonal, aspect, height, distance, pitch, yaw, offset, fontSize, spatialFontSize, opacity, frame, spatial | layout |
| close_window | window_id |  | layout |
| set_pane | window_id, pane_id | kind, url | layout |
| split_pane | window_id, pane_id | kind, axis, ratio | layout |
| close_pane | window_id, pane_id |  | layout |
| plugin_install | manifest | config | plugin-registration |
| plugin_backend | endpoint, confirm_host_access | plugin_id, instance_id | trusted-backend |
| plugin_enable |  | plugin_id, instance_id | plugin-registration |
| plugin_disable |  | plugin_id, instance_id | plugin-registration |
| plugin_remove |  | plugin_id, instance_id | plugin-registration |
| plugin_patch_config | patch | plugin_id, instance_id | plugin-registration |
| plugin_window | settings | plugin_id, instance_id | plugin-registration |
| plugin_configure | config | plugin_id, instance_id | plugin-registration |
| plugin_update | plugin_id, manifest |  | plugin-registration |
| plugin_duplicate |  | plugin_id, name, instance_id | plugin-registration |
| plugin_disable_all |  |  | plugin-registration |
