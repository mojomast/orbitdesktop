export interface WorkspaceExtensionContext {
 token: ()=>string;
 api: (body:Record<string,unknown>)=>Promise<any>;
 agentName?: string;
 provider?: string;
}
export interface WorkspaceExtension {
 id:string; title:string; label:string;
 activate:(context:WorkspaceExtensionContext)=>Promise<void>;
}
// Trusted, built-in modules only. User-generated plugins never execute in this realm.
export const workspaceExtensions: readonly WorkspaceExtension[] = [
 {id:'shared-browser',title:'Shared Chromium',label:'Open shared Chromium',activate:async c=>(await import('./shared-browser')).showSharedBrowser(c.api)},
 {id:'build-queue',title:'Automated build queue',label:'Open automated build queue',activate:async c=>(await import('./build-queue')).showBuildQueue(c.api)},
 {id:'plugins',title:'Workspace plugins',label:'Manage workspace plugins',activate:async c=>(await import('./plugin-manager')).showPlugins(c.token)},
 {id:'checkpoints',title:'Workspace checkpoints',label:'Open workspace checkpoints',activate:async c=>(await import('./workspace-history')).showHistory(c.token)},
 {id:'catalog',title:'Skills and tools',label:'Browse skills and tools for the selected agent',activate:async c=>(await import('./hermes-catalog')).showCatalog(c.api, c.agentName)},
 {id:'outputs',title:'Apps and outputs',label:'Open published apps and outputs',activate:async c=>{await (await import('./hermes-surfaces')).showShelf(c.token);}},
 {id:'jobs',title:'Scheduled tasks',label:'Open scheduled tasks for the selected agent',activate:async c=>(await import('./hermes-jobs')).showHermesJobs(c.api, c.agentName, c.provider)},
];
