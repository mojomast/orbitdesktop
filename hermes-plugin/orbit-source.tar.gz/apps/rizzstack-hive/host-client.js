// A single reviewed document, one port, no credential. Switching to a demo
// releases the grant. Returning to Host reuses only the document channel and
// requires a new click in Orbit. Navigation destroys both.
const pairing = /^#orbit-hive-document=([a-f\d-]{36})$/.exec(location.hash)?.[1];
const unavailable = {openRails:()=>false,refresh:()=>{},close:()=>{}};
let port, callbacks, watchdog, phase='waiting', focusPending=false, expired=false;
const object=v=>!!v && typeof v==='object' && !Array.isArray(v);
const keys=(v,names)=>object(v) && Object.keys(v).length===names.length && names.every(k=>Object.hasOwn(v,k));
// Transport envelope/shape checks. Full snapshot validation, redaction, scope
// membership and the byte ceiling remain on the trusted side of this port.
function viewShape(v) {
  return keys(v,['generatedAt','health','metrics','sections','attempts','stations','attention','records']) &&
    typeof v.generatedAt==='string' && Number.isFinite(Date.parse(v.generatedAt)) && ['live','stale','degraded','unavailable'].includes(v.health) &&
    keys(v.metrics,['active','available','capacity','eligible','cost','costCoverage']) &&
    [['sections',10,10],['stations',8,8],['attempts',0,100],['attention',0,50],['records',0,200]].every(([key,min,max])=>
      Array.isArray(v[key]) && v[key].length>=min && v[key].length<=max && v[key].every(r=>object(r) && typeof r.id==='string'));
}

function arm(ms) {
  clearTimeout(watchdog);
  watchdog=setTimeout(()=>{const state=phase==='waiting'?'unavailable':'disconnected';phase='waiting';focusPending=false;callbacks?.onStatus(state);},ms);
}
function start() {
  // Ordinary plugin CSP allows network. Tighten the reviewed document before
  // offering a port/accepting any private view, independently of the manifest.
  const csp=document.createElement('meta');csp.httpEquiv='Content-Security-Policy';
  csp.content="default-src 'none'; connect-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; form-action 'none'; base-uri 'none'";
  document.head.prepend(csp);
  const {port1,port2}=new MessageChannel();port=port1;
  port.onmessage=({data})=>{
    if (!callbacks || !object(data)) return;
    if (data.type==='status' && keys(data,['type','value']) && ['connected','unauthorized','unavailable','disconnected','loading'].includes(data.value)) {
      if (data.value==='connected' && phase!=='projected') return;
      phase=data.value;
      if(!['connected','loading'].includes(phase)) focusPending=false;
      clearTimeout(watchdog);if(phase==='connected' || phase==='loading') arm(65_000);
      callbacks.onStatus(data.value);
    } else if (data.type==='view' && phase==='loading' && keys(data,['type','view']) && viewShape(data.view)) {
      phase='projected';arm(65_000);callbacks.onView(data.view);
    } else if (data.type==='return-focus' && keys(data,['type']) && focusPending) {focusPending=false;callbacks.onReturnFocus();}
  };
  const dispose=()=>{
    expired=true;phase='waiting';focusPending=false;clearTimeout(watchdog);callbacks?.onStatus('unauthorized');callbacks=null;
    port.postMessage({type:'close'});port.close();
  };
  port.onmessageerror=dispose;
  addEventListener('pagehide',dispose,{once:true});
  parent.postMessage({type:'orbit-hive-ready',document:pairing},new URL(import.meta.url).origin,[port2]);
}

export function connectHost(client) {
  if (!pairing || expired || self===parent || callbacks) {client.onStatus('unavailable');return unavailable;}
  callbacks=client;phase='waiting';focusPending=false;client.onStatus('loading');arm(5_000);
  if (!port) start();else port.postMessage({type:'resume'});
  return {
    openRails(kind,id) {
      if (callbacks!==client || phase!=='connected' || !['attempt','job'].includes(kind) || typeof id!=='string' || !/^[A-Za-z0-9][A-Za-z0-9._:-]{0,191}$/.test(id)) return false;
      focusPending=true;port.postMessage({type:'rails',kind,id});return true;
    },
    refresh(){if(callbacks===client)port.postMessage({type:'refresh'});},
    close(){if(callbacks!==client)return;callbacks=null;phase='waiting';focusPending=false;clearTimeout(watchdog);port.postMessage({type:'suspend'});}
  };
}
