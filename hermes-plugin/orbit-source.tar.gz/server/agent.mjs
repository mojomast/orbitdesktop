import fs from 'node:fs';
import { randomUUID, createHash } from 'node:crypto';
import { createSharedChats } from './shared-chats.mjs';
import { serviceError } from './service-error.mjs';
import { createConversationPrivateStore } from './conversation-private-store.mjs';
import { automation } from './automation.mjs';
import { tokenMatches, allowedRequest } from './security.mjs';
import { createBuildQueue } from './build-queue.mjs';
import { createAgentProfiles, validSessionId, sanitizeSessions, sanitizeHistory } from './agent-profiles.mjs';
import { attachProviders } from './agent-discovery.mjs';
import { applyCalibration, calibrateEstimate, estimateTokens, forkSeed, HERMES_COMPRESSION_NOTE, meterLevel, modelWindow, readReportedUsage, summarizeTranscript, usageBreakdown } from './agent-session-controls.mjs';
import { createGatewayChat } from './gateway-chat.mjs';
import { isGatewayProvider, providerIds, providerLabel } from './agent-providers.mjs';
import { createAgentContextApi, tokenRatioKey, writeTokenRatio } from './agent-context.mjs';
import { calibrate, measureContext } from '../src/context-budget.ts';
import { createAgentGateways } from './agent-gateways.mjs';
import { createSharedAgents } from './shared-agents.mjs';
import { createCollab } from './collab.mjs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const sessionPattern = /^orbit-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const runPattern = /^run_[a-zA-Z0-9_-]{8,100}$/;
const instructions = 'You are Hermes, accessed through the owner’s Comet/Orbit Desktop agent chat. This pane uses its explicitly selected profile and conversation, which may resume a saved Hermes session. Orbit terminal panes run as the owner on the host. Your agent tools still run in the configured Hermes environment. Use plain text in replies. Do not claim to see screen pixels, iframe contents, or terminal buffers unless supplied. Follow normal tool approval policies.';


// Ordinary Hermes run submission for pane-backed conversations. The exact
// upstream payload is frozen once, persisted as a receipt, and dispatched
// verbatim so a lost response can be reconciled instead of duplicated.
const submissionUuid = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/;
const submissionTerminal = new Set(['completed', 'failed', 'cancelled', 'interrupted']);
const IDEMPOTENCY_KEY_HEADER = 'Idempotency-Key';
const MAX_IDEMPOTENCY_RETENTION_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_STATUS_OUTPUT_BYTES = 256 * 1024;
function boundedOutput(value) {
  if (typeof value !== 'string' || !value) return { output: typeof value === 'string' ? value : '', output_truncated: false };
  const bytes = Buffer.from(value, 'utf8');
  if (bytes.length <= MAX_STATUS_OUTPUT_BYTES) return { output: value, output_truncated: false };
  let end = MAX_STATUS_OUTPUT_BYTES;
  while (end > 0 && (bytes[end] & 0xc0) === 0x80) end--;
  return { output: bytes.subarray(0, end).toString('utf8'), output_truncated: true };
}
function createHermesSubmission({ configuration, shared, locks, upstreamFor, validatePane }) {
  const pending = new Map();
  const key = args => `${args.workspace_id}:${args.pane_id}`;
  function configured() {
    if (!configuration) throw serviceError('unavailable');
  }
  const generation = profile => createHash('sha256').update(`${profile.id}\0${profile.apiUrl || ''}\0${profile.apiKey || ''}`).digest('hex');
  function binding(args) {
    configured();
    if (!submissionUuid.test(args.workspace_id || '') || !submissionUuid.test(args.pane_id || '')) throw serviceError('invalid_request');
    try { validatePane(args); } catch (error) { throw serviceError(error.status === 404 ? 'permission_denied' : 'unavailable'); }
    const current = shared.read(args.workspace_id, args.pane_id);
    if (!current) throw serviceError('permission_denied');
    const profile = configuration.get(current.profile_id);
    return { current, profile, recipient: {
      pane_id: args.pane_id, profile_id: current.profile_id, session_id: current.session,
      binding_revision: current.binding_revision,
      config_generation: generation(profile || { id: current.profile_id }),
      trusted_host: true, sandbox: false,
      destination: { trust: 'owner_configured_gateway', known: !!profile },
    } };
  }
  function exact(args, expected) {
    const result = binding(args);
    const r = result.recipient;
    if ((args.profile_id !== undefined && args.profile_id !== r.profile_id) ||
        (args.session_id !== undefined && args.session_id !== r.session_id) ||
        (expected && (expected.binding_revision !== r.binding_revision || expected.config_generation !== r.config_generation))) throw serviceError('stale_resource');
    return result;
  }
  function available(profile) { if (!profile) throw serviceError('unavailable'); }
  async function capabilities(profile) {
    available(profile);
    const result = { configured: true, gateway_known: false, version: null, version_supported: false, capability_advertised: false, installation_verified: false, native_continuation: false, idempotent_submit: false, config_generation: generation(profile) };
    try {
      const data = await upstreamFor(profile, '/v1/capabilities');
      if (data && typeof data === 'object' && !Array.isArray(data)) {
        result.gateway_known = true;
        const version = typeof data.version === 'string' ? data.version : typeof data.api_version === 'string' ? data.api_version : null;
        const actualHermes=data.object==='hermes.api_server.capabilities'&&data.platform==='hermes-agent'&&data.runtime?.mode==='server_agent'&&data.runtime?.tool_execution==='server'&&data.features?.run_submission===true&&data.features?.run_status===true&&data.features?.run_stop===true;
        const versionSupported = actualHermes;
        result.version = actualHermes?'source-contract:d0288be5':typeof version === 'string' ? version.slice(0, 64) : null;
        result.version_supported = versionSupported;
        result.capability_advertised = versionSupported;
        const features = data.features && typeof data.features === 'object' && !Array.isArray(data.features) ? data.features : {};
        result.native_continuation = versionSupported && features.session_resources === true&&features.session_continuity_header==='X-Hermes-Session-Id';
        const retention = Number(features.runs_idempotency?.retention_seconds)*1000;
        result.idempotent_submit = versionSupported && features.runs_idempotency?.supported === true &&features.runs_idempotency?.durable===true&&
          Number.isFinite(retention) && retention > 0 && retention <= MAX_IDEMPOTENCY_RETENTION_MS;
        result.idempotency_retention_ms=result.idempotent_submit?retention:null;
        result.compatibility_basis=actualHermes?'Pinned upstream source/API contract; advertised fields are not installation acceptance':'Unrecognized gateway; explicit legacy compatibility path';
      }
    } catch { /* Unknown capabilities never grant continuation or replay safety. */ }
    return result;
  }
  function transportError(error) {
    return serviceError(error.status === 429 || error.status === 409 ? 'busy' : 'unavailable');
  }
  async function readBinding(args) { return binding(args).recipient; }
  function panePending(args, paneId) {
    configured();
    if (typeof args === 'string') args = { workspace_id: args, pane_id: paneId };
    if (pending.has(key(args))) return true;
    try { return !!shared.read(args.workspace_id, args.pane_id)?.submission_pending; } catch { return false; }
  }
  function validateInput(args) {
    if (!validSessionId(args.session_id) || typeof args.profile_id !== 'string' || typeof args.input !== 'string' || !args.input.trim() || args.input.length > 1048576) throw serviceError('invalid_request');
  }
  async function prepareSubmission(args, trustedInstructions = instructions, allowConcurrent) {
    configured();
    if (typeof trustedInstructions !== 'string' || Buffer.byteLength(trustedInstructions) > 512 * 1024) throw serviceError('limit_exceeded');
    validateInput(args);
    const expected = { binding_revision: args.expected_binding_revision, config_generation: args.expected_config_generation };
    let { current, profile } = exact(args, expected);
    available(profile);
    if (current.run) throw serviceError('busy');
    if (typeof shared.anyActive === 'function' && shared.anyActive(args.workspace_id, args.pane_id, allowConcurrent)) throw serviceError('busy');
    const caps = await capabilities(profile);
    exact(args, expected);
    const payload = { input: args.input, session_id: args.session_id, instructions: trustedInstructions };
    let history = [];
    try {
      const page = await upstreamFor(profile, `/api/sessions/${encodeURIComponent(args.session_id)}/messages?limit=500&offset=0&order=latest`);
      if (!Array.isArray(page?.data) || page.data.length > 500) throw serviceError('unavailable');
      for (const row of page.data) {
        if (!row || typeof row !== 'object' || Array.isArray(row) || typeof row.role !== 'string') throw serviceError('unavailable');
        if (row.role === 'user' || row.role === 'assistant') {
          if (typeof row.content !== 'string' && typeof row.text !== 'string' && !(row.role === 'assistant' && Array.isArray(row.tool_calls) && row.tool_calls.length)) throw serviceError('unavailable');
        }
      }
      history = sanitizeHistory(page);
    } catch (error) {
      const freshOrbit = error.status === 404 && /^orbit-[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(args.session_id) && current.history_unstarted === true;
      if (freshOrbit && current.orbit_owned === true && Array.isArray(current.messages) && current.messages.length) {
        history = sanitizeHistory({ data: current.messages.filter(message => message && typeof message.text === 'string' && !message.text.startsWith('Switched to ')).map(message => ({ role: message.role, content: message.text })) });
      } else if (!freshOrbit || current.messages?.length) {
        if (error.status === 404) throw Object.assign(serviceError('unavailable'), { status: 409, message: 'Conversation history is unavailable. Select New chat explicitly to start a new conversation.' });
        throw transportError(error);
      }
    }
    while (history.length && history.at(-1).role !== 'assistant') history.pop();
    if (!history.length && current.orbit_owned !== true && current.messages?.some(message => message.role === 'user')) throw serviceError('unavailable');
    payload.conversation_history = history.map(({ role, text }) => ({ role,
      content: /[\uD800-\uDBFF]$/.test(text) ? text.slice(0, -1) : text }));
    const latest = exact(args, expected);
    return { recipient: latest.recipient, caps, payload };
  }
  async function dispatchExact(args, allowConcurrent) {
    configured();
    const payload = args.payload;
    if (!payload || typeof payload !== 'object' || Array.isArray(payload) || typeof payload.input !== 'string' || !payload.input.trim()) throw serviceError('invalid_request');
    const expected = { binding_revision: args.expected_binding_revision, config_generation: args.expected_config_generation };
    let { current, profile } = exact(args, expected);
    available(profile);
    const paneKey = key(args), paneLock = `pane:${paneKey}`, lock = `session:${profile.id}:${current.session}`;
    const owned = typeof args.submission_id === 'string' && args.submission_id ? args.submission_id : null;
    const idle = () => {
      const next = exact(args, expected);
      const marker = next.current.submission_pending;
      if (next.current.run || (marker && marker !== owned) || shared.hasActive(profile.id, args.session_id, args.workspace_id, args.pane_id) ||
           (typeof shared.anyActive === 'function' && shared.anyActive(args.workspace_id, args.pane_id, allowConcurrent))) throw serviceError('busy');
      return next.current;
    };
    if (pending.has(paneKey) || locks.has(lock) || locks.has(paneLock)) throw serviceError('busy');
    if (pending.size >= 1024) throw serviceError('limit_exceeded');
    idle();
    const entry = { lock, profile_id: profile.id, session_id: current.session, submission_id: args.submission_id, inFlight: true };
    pending.set(paneKey, entry);
    locks.add(lock);
    locks.add(paneLock);
    let ambiguous = false, posting = false;
    try {
      if (typeof args.authorize === 'function') args.authorize();
      current = idle();
      if (typeof args.submission_id === 'string' && args.submission_id) shared.write(args.workspace_id, args.pane_id, { ...current, submission_pending: args.submission_id });
      if (typeof args.authorize === 'function') args.authorize();
      const headers = typeof args.idempotency_key === 'string' && args.idempotency_key ? { [IDEMPOTENCY_KEY_HEADER]: args.idempotency_key } : {};
      posting = true;
      const data = await upstreamFor(profile, '/v1/runs', payload, 'POST', headers);
      entry.run_id = data?.run_id;
      if (!runPattern.test(data?.run_id || '') || typeof data.status !== 'string') throw serviceError('unavailable');
      if (typeof args.onAccepted === 'function') args.onAccepted({ run_id: data.run_id, status: data.status });
      current = idle();
      shared.write(args.workspace_id, args.pane_id, { ...current, run: data.run_id, submission_pending: args.submission_id || current.submission_pending, messages: [...(current.messages || []), { role: 'user', text: payload.input.slice(0, 16000) }].slice(-100) });
      return { run_id: data.run_id, status: data.status };
    } catch (error) {
      const upstreamStatus = error.upstreamStatus ?? error.status;
      const explicit = error.ambiguous === true;
      const uncertain = posting && (!upstreamStatus || upstreamStatus >= 500 || upstreamStatus === 408);
      ambiguous = explicit || uncertain;
      const failure = error.code && ['stale_resource', 'busy', 'unavailable', 'permission_denied', 'expired'].includes(error.code) ? error : transportError(error);
      if (ambiguous) failure.ambiguous = true;
      throw failure;
    } finally {
      entry.inFlight = false;
      locks.delete(paneLock);
      if (!ambiguous) {
        pending.delete(paneKey);
        locks.delete(lock);
        try { const latest = shared.read(args.workspace_id, args.pane_id); if (!args.preservePending && latest?.submission_pending) shared.write(args.workspace_id, args.pane_id, { ...latest, submission_pending: undefined }); } catch { /* marker best-effort clear only */ }
      }
    }
  }
  async function getRun(args) {
    configured();
    if (!validSessionId(args.session_id) || typeof args.profile_id !== 'string' || !runPattern.test(args.run_id || '')) throw serviceError('invalid_request');
    const profile = configuration.get(args.profile_id);
    available(profile);
    if (typeof args.expected_config_generation === 'string' && args.expected_config_generation !== generation(profile)) throw serviceError('stale_resource');
    let run;
    try { run = await upstreamFor(profile, `/v1/runs/${args.run_id}`); }
    catch (error) { throw transportError(error); }
    if (run?.session_id !== args.session_id) throw serviceError('permission_denied');
    if (typeof run.status !== 'string') throw serviceError('unavailable');
    return { profile, run };
  }
  async function status(args) {
    configured();
    const { run } = await getRun(args);
    const current = shared.read(args.workspace_id, args.pane_id);
    const boundToOriginal = !!current && current.profile_id === args.profile_id && current.session === args.session_id;
    const done = submissionTerminal.has(run.status);
    if (boundToOriginal) {
      const entry = pending.get(key(args));
      if (entry && !entry.inFlight && entry.profile_id === args.profile_id && entry.session_id === args.session_id && (!entry.run_id || entry.run_id === args.run_id)) {
        if (current.run && current.run !== args.run_id) throw serviceError('stale_resource');
        const known = !args.submission_id || !current.submission_pending || current.submission_pending === args.submission_id || entry.submission_id === args.submission_id;
        shared.write(args.workspace_id, args.pane_id, { ...current, run: done ? undefined : args.run_id, ...(done && known ? { submission_pending: undefined } : {}) });
        if (done && known) pending.delete(key(args));
        if (done) locks.delete(entry.lock);
      } else if ((current.run === args.run_id || (!current.run && args.submission_id && current.submission_pending === args.submission_id)) && done) {
        const known = !args.submission_id || !current.submission_pending || current.submission_pending === args.submission_id;
        shared.write(args.workspace_id, args.pane_id, { ...current, run: undefined, ...(known ? { submission_pending: undefined } : {}), messages: [...(current.messages || []), { role: 'assistant', text: typeof run.output === 'string' ? run.output.slice(0, 16000) : `Run ${run.status}.` }].slice(-100) });
      } else if (!current.run && args.submission_id && current.submission_pending === args.submission_id) {
        shared.write(args.workspace_id, args.pane_id, { ...current, run: args.run_id });
      }
    }
    let outputReleased = true;
    if (typeof args.authorize === 'function') {
      try { args.authorize(); } catch { outputReleased = false; }
    }
    const bounded = outputReleased ? boundedOutput(typeof run.output === 'string' ? run.output : '') : { output: '', output_truncated: false };
    return { run_id: args.run_id, status: run.status, output: bounded.output, output_released: outputReleased, output_truncated: bounded.output_truncated, last_event: run.last_event, ...(run.error ? { error: 'Hermes reported a run failure.' } : {}) };
  }
  function acknowledgeUnknown(args) {
    const { current } = exact(args, { binding_revision: args.expected_binding_revision, config_generation: args.expected_config_generation });
    const entry = pending.get(key(args));
    if (current.run || entry?.inFlight || entry?.run_id || current.submission_pending !== args.submission_id) throw serviceError('busy');
    shared.write(args.workspace_id, args.pane_id, { ...current, submission_pending: undefined });
    if (entry) { locks.delete(entry.lock); pending.delete(key(args)); }
  }
  return { readBinding, prepareSubmission, dispatchExact, status, panePending, acknowledgeUnknown };
}

export function createAgentHandler({ token, port, devOrigins, reply, workspaceContext, workspaceRead, runtimeDirectory = process.env.ORBIT_RUNTIME_DIR || fileURLToPath(new URL('../.runtime/', import.meta.url)), apiUrl = process.env.HERMES_API_URL, apiKey = process.env.HERMES_API_KEY, profiles, profilesJson = process.env.HERMES_PROFILES_JSON, additionalProfiles, fetchImpl = fetch, onRunEvent, onNormalAccepted, grokOptions = {} }) {
  // Derived observation only, using the exact run-trace contract. Never await or
  // let an observer alter a receipt, response, approval or dispatch outcome.
  const observeStatus=(binding,run)=>{
    if(!onRunEvent)return;
    try{onRunEvent({...binding,event:{event:'run.status',status:run.status,started_at:run.started_at,ended_at:run.ended_at},at:Date.now()});}catch{}
  };
  let configuration;
  try { configuration = createAgentProfiles({profiles,profilesJson,apiUrl,apiKey}); } catch { configuration = null; }
  if (configuration && Array.isArray(additionalProfiles) && additionalProfiles.length) configuration = attachProviders(configuration, additionalProfiles);
  // One gateway chat per provider. Grok Bot and Pi answer the same command set, so
  // the agent pane, the shared room and Collab reach either of them through the
  // same surface instead of a second copy of the chat code.
  const gatewayOptions = {
    fetchImpl,
    runtimeDirectory,
    ...(typeof grokOptions.now === 'function' ? { now: grokOptions.now } : {}),
    ...(Number.isFinite(grokOptions.acceptanceGraceMs) ? { acceptanceGraceMs: grokOptions.acceptanceGraceMs } : {}),
    ...(Number.isFinite(grokOptions.runTimeoutMs) ? { runTimeoutMs: grokOptions.runTimeoutMs } : {}),
  };
  const chats = new Map();
  for (const provider of providerIds(configuration)) {
    if (!isGatewayProvider(provider)) continue;
    chats.set(provider, createGatewayChat({ provider, ...gatewayOptions }));
  }
  const chatFor = profile => (isGatewayProvider(profile?.provider) ? chats.get(profile.provider) : null);
  const hermesProfile = () => {
    const profile = configuration?.get('default');
    return profile && !isGatewayProvider(profile.provider) ? profile : null;
  };
  const gatewayProfile = provider => {
    const listed = configuration?.list?.find(profile => profile.provider === provider);
    const profile = listed ? configuration.get(listed.id) : null;
    return profile?.apiUrl && profile?.apiKey ? profile : null;
  };
  const gatewayNow = typeof grokOptions.now === 'function' ? grokOptions.now : undefined;
  const gateways = createAgentGateways({ fetchImpl, chats, hermesProfile, gatewayProfile, ...(gatewayNow ? { now: gatewayNow } : {}) });
  const collab = createCollab({
    directory: path.join(runtimeDirectory, 'collab'),
    gateways,
    ...(gatewayNow ? { now: gatewayNow } : {}),
    ...(Number.isFinite(grokOptions.turnTimeoutMs) ? { turnTimeoutMs: grokOptions.turnTimeoutMs } : {}),
    ...(Number.isFinite(grokOptions.advanceIntervalMs) ? { advanceIntervalMs: grokOptions.advanceIntervalMs } : {}),
  });
  const sharedAgents = createSharedAgents({
    directory: path.join(runtimeDirectory, 'shared-agents'),
    fetchImpl,
    chats,
    gateways,
    openCollab: args => collab.openFromRoom(args),
    ...(gatewayNow ? { now: gatewayNow } : {}),
    ...(Number.isFinite(grokOptions.turnTimeoutMs) ? { turnTimeoutMs: grokOptions.turnTimeoutMs } : {}),
    ...(Number.isFinite(grokOptions.advanceIntervalMs) ? { advanceIntervalMs: grokOptions.advanceIntervalMs } : {}),
    hermesProfile,
    gatewayProfile,
  });
  const estimateFactors = new Map();
  const endpoint = (profile, route) => `${profile.apiUrl.replace(/\/$/, '')}${route}`;
  // Bounded upstream JSON: read the real byte stream with a hard cap, cancel on
  // overflow, and decode as fatal UTF-8. There is no unbounded r.json() fallback;
  // a transport that does not expose a byte stream is refused.
  const MAX_UPSTREAM_JSON_BYTES = 2 * 1024 * 1024;
  async function readBoundedJson(response, maxBytes = MAX_UPSTREAM_JSON_BYTES) {
    const stream = response.body;
    if (!stream || typeof stream.getReader !== 'function') throw Object.assign(Error('Upstream response has no bounded byte stream'), { status: 502, upstreamStatus: 502 });
    const reader = stream.getReader();
    const chunks = []; let total = 0;
    try {
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = value instanceof Uint8Array ? value : new Uint8Array(value);
        total += chunk.byteLength;
        if (total > maxBytes) { try { await reader.cancel(); } catch {} throw Object.assign(Error('Upstream response exceeds the bounded JSON limit'), { status: 502, upstreamStatus: 502, code: 'limit_exceeded' }); }
        chunks.push(chunk);
      }
    } finally { try { reader.releaseLock(); } catch {} }
    const bytes = Buffer.concat(chunks.map(chunk => Buffer.from(chunk.buffer, chunk.byteOffset, chunk.byteLength)));
    let text;
    try { text = new TextDecoder('utf-8', { fatal: true }).decode(bytes); } catch { throw Object.assign(Error('Upstream response is not valid UTF-8'), { status: 502, upstreamStatus: 502 }); }
    try { return JSON.parse(text); } catch { throw Object.assign(Error('Upstream response is not valid JSON'), { status: 502, upstreamStatus: 502 }); }
  }
  async function upstreamFor(profile, route, body, method, headers = {}) {
    const r = await fetchImpl(endpoint(profile,route), {
      method: method || (body === undefined ? 'GET' : 'POST'),
      headers: { ...headers, Authorization: `Bearer ${profile.apiKey}`, 'Content-Type': 'application/json' },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      signal: AbortSignal.timeout(20000),
      redirect: 'error',
    });
    if (!r.ok) {
      const error = new Error(r.status === 429 ? 'Hermes is busy. Try again shortly.' : r.status === 404 ? 'This run is no longer available. Start a new message.' : r.status === 409 ? 'The run state changed. Refresh its status and try again.' : 'Hermes could not complete the request. Check the server connection.');
      error.status = [404, 409, 429].includes(r.status) ? r.status : 502;
      error.ambiguous = r.status >= 500 || r.status === 408;
      error.upstreamStatus = r.status;
      throw error;
    }
    return readBoundedJson(r);
  }
  let buildQueue;
  const shared = createSharedChats(path.join(runtimeDirectory,'shared-chats'));
  const conversations = createConversationPrivateStore(path.join(runtimeDirectory, 'conversation-private'));
  const contextApi = createAgentContextApi({ configuration, shared, conversations, chats, upstreamFor, runtimeDirectory, workspaceRead, workspaceContext });
  // Private, bounded intent/receipt journal. Nothing here is workspace layout or
  // project data; credentials are represented only by the adapter's opaque digest.
  const journalDirectory = path.join(runtimeDirectory, 'ordinary-submissions');
  fs.mkdirSync(journalDirectory, { recursive: true, mode: 0o700 });
  fs.chmodSync(journalDirectory, 0o700);
  const receiptPattern = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/;
  const journalLimit = 1024 * 1024;
  function saveSubmission(record) {
    const bytes = JSON.stringify(record);
    if (Buffer.byteLength(bytes) > journalLimit) throw Object.assign(Error('Submission exceeds the private journal limit.'), { status: 413 });
    const dest = path.join(journalDirectory, `${record.receipt_id}.json`);
    const temp = path.join(journalDirectory, randomUUID());
    const fd = fs.openSync(temp, 'wx', 0o600);
    try { fs.writeFileSync(fd, bytes); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    try {
      fs.renameSync(temp, dest);
      const dir = fs.openSync(journalDirectory, 'r');
      try { fs.fsyncSync(dir); } finally { fs.closeSync(dir); }
    } finally { try { fs.unlinkSync(temp); } catch {} }
  }
  function readSubmission(body, linked = shared.read(body.workspace_id, body.pane_id)) {
    const id = linked?.ordinary_submission_id;
    if (!id) return null;
    if (!receiptPattern.test(id)) throw Object.assign(Error('Submission receipt unavailable; investigation required.'), { status: 409 });
    const file = path.join(journalDirectory, `${id}.json`);
    if (fs.statSync(file).size > journalLimit) throw Object.assign(Error('Submission receipt exceeds its limit.'), { status: 409 });
    const record = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (record.receipt_id !== id || record.workspace_id !== body.workspace_id || record.recipient.pane_id !== body.pane_id) throw Object.assign(Error('Submission receipt does not match this pane.'), { status: 409 });
    return record;
  }
  const originalArgs = record => ({ workspace_id: record.workspace_id, ...record.recipient, expected_binding_revision: record.recipient.binding_revision, expected_config_generation: record.recipient.config_generation, submission_id: record.receipt_id, run_id: record.run_id });
  const publicReceipt = record => ({ receipt_id: record.receipt_id, payload_hash: record.payload_hash, submission_state: record.state, ...(record.run_id ? { run_id: record.run_id } : {}), note: 'Never resend an unresolved submission. Inspect the original upstream before acknowledging an unknown outcome.' });
  // Only the trusted Normal-chat caller may relax cross-conversation exclusion.
  // Durable accepted receipts distinguish ordinary runs from uncertain/legacy
  // work, including after restart. Same-session exclusion stays.
  const concurrentOrdinary = args => (state, workspace_id, pane_id) => {
    const profileId = state.profile_id || 'default';
    if (profileId === args.profile_id && state.session === args.session_id) return false;
    if (!state.run || !state.ordinary_submission_id || state.submission_pending !== state.ordinary_submission_id) return false;
    const record = readSubmission({workspace_id,pane_id}, state), profile = configuration?.get(profileId);
    return !!profile && record?.state === 'accepted' && record.run_id === state.run &&
      record.recipient.profile_id === profileId && record.recipient.session_id === state.session &&
      record.recipient.binding_revision === state.binding_revision &&
      record.recipient.config_generation === createHash('sha256').update(`${profile.id}\0${profile.apiUrl || ''}\0${profile.apiKey || ''}`).digest('hex');
  };
  function validatePane(body) {
    if(!workspaceRead)throw Object.assign(Error('Authoritative workspace access unavailable'),{status:503});
    let record;
    try {record=workspaceRead(body.workspace_id);}catch(error) {throw Object.assign(Error('Workspace unavailable'),{status:error.code==='ENOENT'?404:503});}
    // The standalone Collab app is a browser pane at orbit://surface/collab (not an agent pane); it may
    // only use the collab action. Every other pane-scoped action still needs a real agent chat pane.
    const surfaceOk = pane => body.action === 'collab' && pane.kind === 'browser' && String(pane.url || '').split('#')[0] === 'orbit://surface/collab';
    const contains = layout => layout.type === 'pane' ? layout.pane.id === body.pane_id && (layout.pane.kind === 'agent' || surfaceOk(layout.pane)) : contains(layout.first) || contains(layout.second);
    if (!record.state.monitors.some(m => contains(m.layout))) throw Object.assign(Error(body.action === 'collab' ? 'Collab pane is not open in this workspace' : 'Chat pane is not open in this workspace'),{status:404});
  }
  const agent = async function agent(req, res) {
    if (req.method !== 'POST' || !allowedRequest(req, port, devOrigins)) return reply(res, 403, { error: 'Origin rejected' });
    const auth = req.headers.authorization || '';
    if (!auth.startsWith('Bearer ') || !tokenMatches(auth.slice(7), token)) return reply(res, 401, { error: 'Use Connect host with the Orbit session token first.' });
    res.setHeader('Cache-Control','no-store');
    if (!configuration || !configuration.list.length) return reply(res, 503, { error: 'Hermes is not configured on this Orbit server.' });
    let paneLock;
    try {
      const chunks = []; let bytes = 0;
      for await (const part of req) {
        bytes += part.length;
        if (bytes > 1048576) return reply(res, 413, { error: 'Message request exceeds 1 MiB.' });
        chunks.push(part);
      }
      const raw = Buffer.concat(chunks).toString('utf8');
      let body;
      try { body = JSON.parse(raw); } catch { return reply(res, 400, { error: 'Invalid JSON' }); }
      if (!body || typeof body !== 'object') return reply(res,400,{error:'Invalid request.'});
      if (body.pane_id && ['start', 'submission_status', 'acknowledge_submission_unknown'].includes(body.action)) {
        const fields = new Set(['action','workspace_id','pane_id','session_id','profile_id','expected_binding_revision', ...(body.action === 'start' ? ['input'] : body.action === 'acknowledge_submission_unknown' ? ['payload_hash','upstream_investigated'] : [])]);
        if (Object.keys(body).some(key => !fields.has(key))) return reply(res,400,{error:'Unexpected submission request field.'});
      }
      if (body.action === 'profiles') return reply(res,200,{profiles:configuration.list,default_profile_id:'default'});
      if (body.action === 'provider_menu') return reply(res, 200, await contextApi.providerMenu(body));
      if (body.action === 'history_search') return reply(res, 200, await contextApi.historySearch(body));
      if (body.action === 'history_transcript') return reply(res, 200, await contextApi.historyTranscript(body));
      if (['conversation_library', 'conversation_metadata', 'draft_read', 'draft_write'].includes(body.action)) {
        const fields = new Set(['action', 'workspace_id', 'profile_id', ...(body.action === 'conversation_library' ? ['offset'] : ['session_id', ...(body.action === 'draft_read' ? [] : ['expected_revision', body.action === 'draft_write' ? 'text' : 'patch'])])]);
        if (Object.keys(body).some(key => !fields.has(key)) || !/^[a-f0-9-]{36}$/.test(body.workspace_id || '') || !configuration.get(body.profile_id)) return reply(res,400,{error:'Invalid conversation scope or fields.'});
        if (!workspaceRead) return reply(res,503,{error:'Authoritative workspace access unavailable.'});
        try { workspaceRead(body.workspace_id); } catch { return reply(res,404,{error:'Workspace unavailable.'}); }
        const publicMetadata = record => ({session_id:record.session_id,profile_id:record.profile_id,title:record.title,pinned:record.pinned,archived:record.archived,revision:record.revision});
        if (body.action === 'conversation_library') {
          const offset = body.offset ?? 0;
          if (!Number.isSafeInteger(offset) || offset < 0 || offset > 10000) return reply(res,400,{error:'Invalid session page.'});
          const target = configuration.get(body.profile_id);
          let page = {data:[],has_more:false}, supported = true;
          try {
            const libraryChat = chatFor(target);
            page = sanitizeSessions(libraryChat ? await libraryChat.sessionPage(target, offset) : await upstreamFor(target,`/api/sessions?limit=100&offset=${offset}`));
          }
          catch (error) { if (error.status !== 404) throw error; supported = false; }
          const metadata = conversations.list(body.workspace_id,body.profile_id).map(publicMetadata);
          const rows = new Map(page.data.map(item => [item.id,{session_id:item.id,profile_id:body.profile_id,upstream_title:item.title,updated_at:item.updated_at,...publicMetadata(conversations.read({...body,session_id:item.id}))}]));
          if (offset === 0) for (const item of metadata) if (!rows.has(item.session_id)) rows.set(item.session_id,{...item,upstream_title:'',catalog_missing:true});
          return reply(res,200,{conversations:[...rows.values()],supported,has_more:offset < 10000 && (page.has_more || page.data.length === 100),note:'Search covers loaded titles and IDs, not message content. Orbit names, pins and archive flags do not modify Hermes.'});
        }
        if (!validSessionId(body.session_id)) return reply(res,400,{error:'Invalid conversation identity.'});
        if (body.action === 'draft_read') return reply(res,200,{record:conversations.read(body)});
        if (!Number.isSafeInteger(body.expected_revision) || body.expected_revision < 0) return reply(res,400,{error:'A private record revision is required.'});
        let patch;
        if (body.action === 'draft_write') {
          if (typeof body.text !== 'string' || body.text.length > 100000) return reply(res,400,{error:'Draft exceeds 100,000 characters.'});
          patch = {draft:body.text};
        } else {
          patch = body.patch;
          if (!patch || typeof patch !== 'object' || Array.isArray(patch) || !Object.keys(patch).length || Object.keys(patch).some(key => !['title','pinned','archived'].includes(key)) || ('title' in patch && (typeof patch.title !== 'string' || patch.title.length > 200 || /[\x00-\x1f\x7f]/.test(patch.title))) || ['pinned','archived'].some(key => key in patch && typeof patch[key] !== 'boolean')) return reply(res,400,{error:'Invalid Orbit conversation metadata.'});
        }
        const result = conversations.write(body,body.expected_revision,patch);
        return reply(res,result.conflict ? 409 : 200,{conflict:result.conflict,record:body.action === 'draft_write' ? result.record : publicMetadata(result.record)});
      }
      const profileId = body.profile_id === undefined ? 'default' : body.profile_id;
      const profile = configuration.get(profileId);
      // A removed profile must fail closed for execution, but the owner still
      // needs to read the binding and explicitly select a configured replacement.
      if (!profile && !['shared_chat','sessions','select_session'].includes(body.action)) return reply(res,400,{error:'Unknown Hermes profile.'});
      const upstream = (route, payload, method) => upstreamFor(profile,route,payload,method);
      if (!validSessionId(body.session_id) || (!body.pane_id && !sessionPattern.test(body.session_id))) return reply(res, 400, { error: 'Invalid Orbit conversation.' });
      if (body.pane_id) {
        if (!/^[a-f0-9-]{36}$/.test(body.workspace_id || '') || !/^[a-f0-9-]{36}$/.test(body.pane_id)) return reply(res,400,{error:'Invalid shared pane'});
        validatePane(body);
        if (['select_session', 'shared_chat', 'start'].includes(body.action) && submissions.panePending(body)) {
          const receipt = readSubmission(body);
          if (!receipt || body.action !== 'shared_chat') return reply(res,409,{error: receipt ? 'This chat submission is unresolved. Use submission_status; do not resend.' : 'A chat submission is unresolved for this pane. Reconcile it before switching conversations.', ...(receipt ? publicReceipt(receipt) : {})});
        }
        const candidateLock = `pane:${body.workspace_id}:${body.pane_id}`;
        if(shared.locks.has(candidateLock)) return reply(res,409,{error:'This pane is busy; retry shortly.'});
        paneLock = candidateLock;
        shared.locks.add(paneLock);
        if (body.action === 'shared_agents') return sharedAgents.handle(reply, res, body);
        if (body.action === 'collab') return collab.handle(reply, res, body);
        if (body.action === 'sessions') {
          const target = configuration.get(body.target_profile_id);
          if (!target) return reply(res,400,{error:'Unknown Hermes profile.'});
          const sessionChat = chatFor(target);
          if (sessionChat) { const page = sanitizeSessions(await sessionChat.sessionPage(target, 0)); return reply(res,200,{sessions:page.data,supported:true}); }
          try { const data = await upstreamFor(target,'/api/sessions?limit=100&offset=0'); return reply(res,200,{sessions:sanitizeSessions(data).data,supported:true}); }
          catch(error) { if (error.status === 404) return reply(res,200,{sessions:[],supported:false,note:'Session catalog unavailable on this Hermes version.'}); throw error; }
        }
        if (body.action === 'shared_chat') {
          if(body.replace === true) return reply(res,409,{error:'Use validated session selection to change conversations.'});
          const state = shared.bind(body.workspace_id,body.pane_id,body.initial);
          if (state) { const metadata=conversations.read({workspace_id:body.workspace_id,profile_id:state.profile_id || 'default',session_id:state.session}); if(metadata.title) state.title=metadata.title; }
          return reply(res,200,{state});
        }
        const linked = shared.read(body.workspace_id,body.pane_id);
        if (!linked) return reply(res,409,{error:'This chat has not linked yet. Open it on the desktop and reload once.'});
        const revision = body.expected_binding_revision;
        if (body.action === 'select_session') {
          if (revision !== linked.binding_revision || linked.session !== body.session_id || linked.profile_id !== profileId || linked.run || shared.locks.has(`session:${linked.profile_id}:${linked.session}`)) return reply(res,409,{error:'Conversation changed or is still running.'});
          const target = configuration.get(body.target_profile_id);
          if (!target) return reply(res,400,{error:'Unknown Hermes profile.'});
          const selectChat = chatFor(target);
          if (selectChat) return selectChat.selectSession(reply, res, { body, target, revision, profileId, shared, validatePane, conversations });
          const creating = body.target_session_id === undefined || body.target_session_id === null;
          const targetId = creating ? `orbit-${randomUUID()}` : body.target_session_id;
          if (!validSessionId(targetId)) return reply(res,400,{error:'Invalid Hermes session.'});
          if (shared.locks.has(`session:${target.id}:${targetId}`) || shared.hasActive(target.id,targetId,body.workspace_id,body.pane_id)) return reply(res,409,{error:'This conversation is already running.'});
          let title;
          let messages=[];
          try { if (!creating) {
            const metadata = await upstreamFor(target,`/api/sessions/${encodeURIComponent(targetId)}`);
            if (metadata.id !== targetId) return reply(res,404,{error:'Hermes session not found.'});
            title = typeof metadata.title === 'string' ? metadata.title.slice(0,100) : undefined;
            const history = await upstreamFor(target,`/api/sessions/${encodeURIComponent(targetId)}/messages?limit=80&offset=0`);
            messages = sanitizeHistory(history);
          }
          } catch(error) { if (error.status === 404) return reply(res,404,{error:'Hermes session not found.'}); throw error; }
           const current = shared.read(body.workspace_id,body.pane_id);
           validatePane(body);
           if (shared.locks.has(`session:${target.id}:${targetId}`) || shared.hasActive(target.id,targetId,body.workspace_id,body.pane_id)) return reply(res,409,{error:'This conversation is already running.'});
           if (current.binding_revision !== revision || current.session !== body.session_id || current.profile_id !== profileId || current.run) return reply(res,409,{error:'Conversation changed or is still running.'});
            const display=conversations.read({workspace_id:body.workspace_id,profile_id:target.id,session_id:targetId});
            const state = shared.write(body.workspace_id,body.pane_id,{session:targetId,profile_id:target.id,binding_revision:revision+1,messages,title:display.title || title,history_unstarted:creating});
          return reply(res,200,{state});
        }
        if (body.action === 'context_meter' || body.action === 'session_preview' || body.action === 'compact_session' || body.action === 'fork_session') {
          if (revision !== linked.binding_revision || linked.session !== body.session_id || linked.profile_id !== profileId) return reply(res,409,{error:'This pane is linked to another conversation. Wait for synchronization.'});
          if (body.action === 'compact_session' && body.confirm !== true) return reply(res,400,{error:'Confirm compact before changing this session.'});
          if (body.action === 'fork_session' && body.confirm !== true) return reply(res,400,{error:'Confirm before forking this session.'});
          if ((body.action === 'compact_session' || body.action === 'fork_session') && linked.run) return reply(res,409,{error:'Conversation changed or is still running.'});
          if (body.action === 'fork_session') {
            const sourceProfileId = typeof body.source_profile_id === 'string' ? body.source_profile_id : profileId;
            const source = configuration.get(sourceProfileId);
            const sourceSession = typeof body.source_session_id === 'string' ? body.source_session_id : body.session_id;
            const targetProfileId = typeof body.target_profile_id === 'string' ? body.target_profile_id : sourceProfileId;
            const target = configuration.get(targetProfileId);
            if (!source || !target || !validSessionId(sourceSession)) return reply(res,400,{error:'Invalid conversation to fork.'});
            let transcript = [];
            const sourceChat = chatFor(source);
            if (sourceChat) {
              const preview = await sourceChat.previewSession(source, sourceSession);
              transcript = preview.messages || [];
              if (preview.resumable === false && !transcript.length) return reply(res,409,{error:'This session cannot be forked because its transcript is unavailable.'});
            } else {
              try {
                const history = await upstreamFor(source, `/api/sessions/${encodeURIComponent(sourceSession)}/messages?limit=80&offset=0`);
                transcript = sanitizeHistory(history);
              } catch (error) {
                if (error.status !== 404) throw error;
                if (sourceSession === linked.session && source.id === profileId) transcript = linked.messages || [];
                else return reply(res,409,{error:'This session cannot be forked because its transcript is unavailable.'});
              }
            }
            const through = body.through_index === undefined ? Math.max(0, transcript.length - 1) : body.through_index;
            if (transcript.length && (!Number.isInteger(through) || through < 0 || through >= transcript.length)) return reply(res,400,{error:'Fork from a message in this transcript.'});
            const slice = transcript.length ? transcript.slice(0, through + 1) : [];
            const summary = summarizeTranscript(slice);
            const sourceProvider = isGatewayProvider(source.provider) ? source.provider : 'hermes';
            const targetProvider = isGatewayProvider(target.provider) ? target.provider : 'hermes';
            const cross = sourceProvider !== targetProvider;
            const seed = forkSeed({ summary, sourceSession, sourceProvider, targetProvider, through: transcript.length ? through : undefined, cross });
            const forkChat = chatFor(target);
            if (forkChat) return forkChat.forkSession(reply, res, { body, target, revision, profileId, shared, conversations, seed, summary, sourceSession, cross });
            const created = `orbit-${randomUUID()}`;
            if (shared.locks.has(`session:${target.id}:${created}`) || shared.hasActive(target.id, created, body.workspace_id, body.pane_id)) return reply(res,409,{error:'This conversation is already running.'});
            const title = `Fork of ${String(sourceSession).slice(-12)}`.slice(0, 100);
            try { conversations.write({ workspace_id: body.workspace_id, profile_id: target.id, session_id: created }, 0, { title }); } catch { /* the pane title still shows the fork */ }
            const text = seed.slice(0, 16000);
            const state = shared.write(body.workspace_id, body.pane_id, {
              session: created, profile_id: target.id, binding_revision: revision + 1,
              messages: [{ role: 'user', text }], title, history_unstarted: true, fork_preface: text,
            });
            const published = { ...state };
            delete published.fork_preface;
            return reply(res,200,{ state: published, strategy: cross ? 'cross-provider-fork' : 'fork', previous_session_id: sourceSession, session_id: created, summary, note: `Forked into ${created}. The original session stays unchanged.` });
          }
          if (body.action === 'session_preview') {
            const target = configuration.get(body.target_profile_id);
            if (!target || !validSessionId(body.target_session_id)) return reply(res,400,{error:'Invalid conversation preview.'});
            const previewChat = chatFor(target);
            if (previewChat) return reply(res,200,{...await previewChat.previewSession(target, body.target_session_id), provider: target.provider});
            try {
              const history = await upstreamFor(target, `/api/sessions/${encodeURIComponent(body.target_session_id)}/messages?limit=80&offset=0`);
              return reply(res,200,{messages:sanitizeHistory(history), resumable:true, provider:'hermes'});
            } catch (error) {
              if (error.status === 404) return reply(res,200,{messages:[], resumable:false, provider:'hermes', note:'This Hermes session cannot be resumed from here.'});
              throw error;
            }
          }
          const profileChat = chatFor(profile);
          if (profileChat) {
            if (body.action === 'compact_session') return profileChat.compactSession(reply, res, { body, target: profile, revision, profileId, shared, conversations });
            const preview = await profileChat.previewSession(profile, body.session_id);
            const text = preview.messages.map(item => item.text).join('\n');
            const rawEstimate = estimateTokens(text);
            const modelName = typeof profile.model === 'string' ? profile.model : '';
            const factor = estimateFactors.get(`${profileId}:${modelName || profile.provider}`) || 1;
            const meter = meterLevel(applyCalibration(rawEstimate, factor), modelWindow(modelName));
            return reply(res,200,{...meter, source:'estimated', calibrated: factor !== 1, breakdown: usageBreakdown(null, rawEstimate, text.length), model: modelName, tools:true, provider: profile.provider, hermes_compression:null});
          }
          if (body.action === 'compact_session') {
            const response = await fetchImpl(endpoint(profile, `/api/sessions/${encodeURIComponent(body.session_id)}/compress`), {
              method: 'POST',
              headers: { Authorization: `Bearer ${profile.apiKey}`, 'Content-Type': 'application/json' },
              body: '{}',
              signal: AbortSignal.timeout(20000),
              redirect: 'error',
            });
            if ([404, 405, 501].includes(response.status)) {
              try { await response.body?.cancel?.(); } catch { /* already closed */ }
              return reply(res,200,{strategy:'hermes-native', applied:false, note:HERMES_COMPRESSION_NOTE});
            }
            if (!response.ok) {
              try { await response.body?.cancel?.(); } catch { /* already closed */ }
              return reply(res,502,{error:'Hermes could not compact this session.'});
            }
            let summary = '';
            try { const data = await readBoundedJson(response); summary = typeof data?.summary === 'string' ? data.summary.slice(0, 4000) : ''; }
            catch { summary = ''; }
            return reply(res,200,{strategy:'hermes-native', applied:true, summary, note: summary || 'Hermes compressed this session.'});
          }
          let session = null;
          try { session = await upstream(`/api/sessions/${encodeURIComponent(body.session_id)}`); }
          catch (error) { if (error.status !== 404) throw error; }
          const reported = readReportedUsage(session);
          const localText = (Array.isArray(linked.messages) ? linked.messages : []).map(item => item.text || '').join('\n');
          let sampleText = localText;
          if (!reported.used && !estimateTokens(sampleText)) {
            try {
              const history = await upstream(`/api/sessions/${encodeURIComponent(body.session_id)}/messages?limit=80&offset=0`);
              sampleText = sanitizeHistory(history).map(item => item.text).join('\n');
            } catch (error) { if (error.status !== 404) throw error; }
          }
          const rawEstimate = estimateTokens(sampleText);
          const model = reported.model || '';
          const factorKey = `${profileId}:${model || 'default'}`;
          let factor = estimateFactors.get(factorKey) || 1;
          if (reported.used && rawEstimate) {
            const sample = calibrateEstimate(rawEstimate, reported.used);
            if (sample.calibrated) { factor = sample.factor; estimateFactors.set(factorKey, factor); }
          }
          const meter = meterLevel(reported.used || applyCalibration(rawEstimate, factor), reported.window || modelWindow(model));
          return reply(res,200,{...meter, source: reported.used ? 'reported' : 'estimated', calibrated: !reported.used && factor !== 1, breakdown: usageBreakdown(session, rawEstimate, sampleText.length), model, tools:true, provider:'hermes', hermes_compression:{native:true, detail:HERMES_COMPRESSION_NOTE}});
        }
        if(linked.session !== body.session_id || linked.profile_id !== profileId || revision !== linked.binding_revision) return reply(res,409,{error:'This pane is linked to another conversation. Wait for synchronization.'});
        if (body.action === 'compact_transcript') return reply(res, 200, await contextApi.compact(body, linked));
        if (body.action === 'switch_provider') return reply(res, 200, await contextApi.switchProvider(body, linked));
        if (body.action === 'fork_transcript') return reply(res, 200, await contextApi.fork(body, linked));
        const receipt = readSubmission(body, linked);
        if (linked.submission_pending && receipt && ['status','stop','steer','approval','events'].includes(body.action) && (!receipt.run_id || body.run_id !== receipt.run_id)) return reply(res,409,{error:'Use submission_status to inspect this pane’s original submission.',...publicReceipt(receipt)});
        if (['submission_status', 'acknowledge_submission_unknown'].includes(body.action)) {
          if (!receipt) return reply(res,404,{error:'No ordinary submission receipt for this pane.'});
          if (body.action === 'acknowledge_submission_unknown') {
            if (receipt.run_id || !['prepared','dispatching','submission_unknown'].includes(receipt.state) || body.payload_hash !== receipt.payload_hash || body.upstream_investigated !== true) return reply(res,409,{error:'Acknowledge the exact digest only after investigating the original upstream and confirming no run remains active.'});
            submissions.acknowledgeUnknown(originalArgs(receipt));
            receipt.state = 'denied'; receipt.owner_acknowledged = true;
            saveSubmission(receipt);
            return reply(res,200,publicReceipt(receipt));
          }
          if (!receipt.run_id) return reply(res,200,publicReceipt(receipt));
          const result = await submissions.status(originalArgs(receipt));
          observeStatus({workspace_id:receipt.workspace_id,profile_id:receipt.recipient.profile_id,session_id:receipt.recipient.session_id,run_id:receipt.run_id},result);
          return reply(res,200,{...publicReceipt(receipt),...result});
        }
        // Fence every ordinary control request against credential/endpoint changes,
        // before a stored run identifier can be sent to a different gateway.
        if (receipt?.run_id && receipt.run_id === body.run_id) {
          const recipient = await submissions.readBinding(body);
          if (recipient.config_generation !== receipt.recipient.config_generation) return reply(res,409,{error:'The original Hermes configuration changed. Restore it before inspecting this run.'});
          if (body.action === 'status') {
            const result = await submissions.status(originalArgs(receipt));
            observeStatus({workspace_id:receipt.workspace_id,profile_id:receipt.recipient.profile_id,session_id:receipt.recipient.session_id,run_id:receipt.run_id},result);
            let approvals = [];
            if (result.status === 'waiting_for_approval') {
              const pending = await upstream(`/v1/approvals/pending?session_id=${encodeURIComponent(receipt.run_id)}`);
              approvals = (pending.approvals || []).map(a => ({command:String(a.command || a.description || a.tool_name || 'Tool execution requires approval').slice(0,4000),reason:String(a.reason || '').slice(0,1000)}));
            }
            return reply(res,200,{...result,approvals});
          }
        }
      }
      const providerChat = chatFor(profile);
      if (providerChat && body.action === 'build_queue') return reply(res, 409, { error: `The build queue uses Hermes workers. ${providerLabel(profile?.provider)} has no build-queue API.` });
      if (providerChat && body.action === 'events') {
        if (paneLock) { shared.locks.delete(paneLock); paneLock = undefined; }
        return providerChat.events(reply, res, { body, profile, shared });
      }
      if (providerChat && ['catalog', 'capabilities', 'activity', 'automation', 'jobs', 'job_control'].includes(body.action)) {
        return providerChat.surface(reply, res, { body, profile });
      }
      if (body.action === 'build_queue') {
        if (profileId !== 'default') return reply(res,409,{error:'Build queue is only available for the default Hermes profile.'});
        buildQueue ||= createBuildQueue({ directory: path.join(runtimeDirectory,'build-queue'), upstream, context: workspaceContext });
        try {
          if (body.operation === 'approvals') return reply(res, 200, { approvals: await buildQueue.approvals(body) });
          return reply(res, 200, await buildQueue.action(body));
        } catch (error) { return reply(res, 409, { error: error.message }); }
      }
      if (body.action === 'catalog') {
        if (!['skills', 'toolsets'].includes(body.kind)) return reply(res, 400, { error: 'Invalid catalog.' });
        const caps = await upstream('/v1/capabilities');
        if (!caps.endpoints?.[body.kind]) return reply(res, 409, { error: 'This gateway does not advertise this catalog.' });
        const data = await upstream(`/v1/${body.kind}`);
        const fields = body.kind === 'skills' ? ['name', 'description', 'category'] : ['name', 'label', 'description', 'enabled', 'configured', 'tools'];
        return reply(res, 200, { items: (Array.isArray(data.data) ? data.data : []).slice(0, 500).map(item => Object.fromEntries(fields.filter(k => item[k] !== undefined).map(k => [k, k === 'tools' ? (Array.isArray(item[k]) ? item[k].slice(0, 200).map(x => String(x).slice(0, 100)) : []) : typeof item[k] === 'boolean' ? item[k] : String(item[k]).slice(0, 2000)]))) });
      }
      if (body.action === 'capabilities') {
        const data = await upstream('/v1/capabilities');
        return reply(res, 200, { features: { run_events_sse: data.features?.run_events_sse === true } });
      }
      if (body.action === 'events') {
        if (!runPattern.test(body.run_id || '')) return reply(res, 400, { error: 'Invalid run.' });
        const run = await upstream(`/v1/runs/${body.run_id}`);
        if (run.session_id !== body.session_id) return reply(res, 404, { error: 'Run not found in this Orbit conversation.' });
        const caps = await upstream('/v1/capabilities');
        if (!caps.features?.run_events_sse) return reply(res, 409, { error: 'Streaming unavailable; use status polling.' });
        // Read-only streams must not starve status/stop/approval requests.
        if (paneLock) { shared.locks.delete(paneLock); paneLock = undefined; }
        const abort = new AbortController(); res.on('close', () => abort.abort());
        const stream = await fetchImpl(endpoint(profile,`/v1/runs/${body.run_id}/events`), { headers: { Authorization: `Bearer ${profile.apiKey}` }, signal: abort.signal, redirect: 'error' });
        if (!stream.ok) return reply(res, 502, { error: 'Activity stream unavailable; use status polling.' });
        let tee;
        // Only pane-backed requests have an authoritative workspace/profile/
        // session binding. Legacy unbound requests are forwarded without traces.
        if(onRunEvent&&body.pane_id){try{const {createRunTraceTee}=await import('./run-trace-tee.mjs');tee=createRunTraceTee({binding:{workspace_id:body.workspace_id,profile_id:profileId,session_id:body.session_id,run_id:body.run_id},onRunEvent});}catch{}}
        res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', 'X-Accel-Buffering': 'no' });
        try { for await (const chunk of stream.body) { try{tee?.write(chunk);}catch{} if (!res.write(chunk)) await new Promise(resolve => { res.once('drain', resolve); res.once('close', resolve); }); if (res.destroyed) break; } } finally { try{tee?.close();}catch{} abort.abort(); res.end(); }
        return;
      }
      if(body.action==='connection_password') {
        const paths = {chromium:'shared-browser/password.txt', xpra:'xpra/password'};
        if (!Object.hasOwn(paths, body.service)) return reply(res,400,{error:'Unknown connection.'});
        res.setHeader('Cache-Control','no-store');
        return reply(res,200,{password:fs.readFileSync(path.join(runtimeDirectory,paths[body.service]),'utf8').trim()});
      }
      if(body.action==='shared_browser_connection') {
        const password=fs.readFileSync(path.join(runtimeDirectory,'shared-browser/password.txt'),'utf8').trim();
        res.setHeader('Cache-Control','no-store');
        return reply(res,200,{url:'/vnc.html?autoconnect=true&resize=scale',port:4344,password});
      }
      if(body.action==='automation') return reply(res,200,await automation(body,upstream));
      if (body.action === 'job_control') {
        if (!['pause', 'resume'].includes(body.operation) || typeof body.job_id !== 'string' || !/^[a-zA-Z0-9_-]{1,100}$/.test(body.job_id) || body.confirm !== true) return reply(res, 400, { error: 'Confirm a valid pause or resume operation.' });
        await upstream(`/api/jobs/${encodeURIComponent(body.job_id)}/${body.operation}`, {});
        return reply(res, 200, { accepted: true, operation: body.operation });
      }
      if (body.action === 'jobs') {
        const data = await upstream('/api/jobs?include_disabled=true');
        const fields = ['id', 'name', 'enabled', 'state', 'schedule', 'schedule_display', 'next_run_at', 'last_run_at', 'last_status', 'paused'];
        const jobs = (Array.isArray(data.jobs) ? data.jobs : []).slice(0, 200).map(job => Object.fromEntries(fields.filter(k => job[k] !== undefined).map(k => [k, typeof job[k] === 'object' ? JSON.stringify(job[k]).slice(0, 1000) : typeof job[k] === 'string' ? job[k].slice(0, 1000) : job[k]])));
        return reply(res, 200, { jobs });
      }
      if (body.action === 'activity') {
        const data = await upstream(`/api/sessions/${body.session_id}/messages?limit=80&order=latest`);
        const activity = [];
        let budget = 80000;
        for (const m of (data.data || []).slice(-80)) {
          for (const call of (Array.isArray(m.tool_calls) ? m.tool_calls : []).slice(0, 100 - activity.length)) {
            const f = call.function || call;
            const detail = (typeof f.arguments === 'string' ? f.arguments : JSON.stringify(f.arguments || {})).slice(0, Math.min(4000, budget)); budget -= detail.length;
            activity.push({ kind: 'call', name: String(f.name || 'tool').slice(0, 100), id: String(call.id || '').slice(0, 150), detail });
          }
          if (m.role === 'tool') {
            const detail = String(m.content || '').slice(0, Math.min(8000, budget)); budget -= detail.length;
            activity.push({ kind: 'result', name: String(m.name || 'Tool result').slice(0, 100), id: String(m.tool_call_id || '').slice(0, 150), detail });
          }
          if (budget <= 0 || activity.length >= 100) break;
        }
        return reply(res, 200, { activity, note: 'Persisted tool history for this conversation; active tools may appear only after Hermes saves them. Results are truncated.' });
      }
      if (body.action === 'start') {
        const turnChat = chatFor(profile);
        if (turnChat) return turnChat.turn(reply, res, { body, profile, shared, workspaceContext });
        if (typeof body.input !== 'string' || !body.input.trim() || body.input.length > 100000) return reply(res, 400, { error: 'Enter a message of 1–100,000 characters.' });
        if (body.pane_id) {
          const receiptId = randomUUID();
          let record;
          try {
            if (fs.readdirSync(journalDirectory).length >= 1024) return reply(res,409,{error:'Private submission journal is full; archive resolved receipts before continuing.'});
            let context = '';
            try { if (workspaceContext) context = workspaceContext(body.workspace_id); }
            catch { return reply(res,409,{error:'Workspace has not synced yet. Wait for workspace connection and retry.'}); }
            const recipient = await submissions.readBinding(body);
            const args = {workspace_id:body.workspace_id,pane_id:body.pane_id,profile_id:profileId,session_id:body.session_id,input:body.input.trim(),expected_binding_revision:body.expected_binding_revision,expected_config_generation:recipient.config_generation};
            const allowConcurrent = concurrentOrdinary(args);
            const prepared = await submissions.prepareSubmission(args, instructions + context, allowConcurrent);
            record = {receipt_id:receiptId,workspace_id:body.workspace_id,recipient:prepared.recipient,payload:prepared.payload,payload_hash:createHash('sha256').update(JSON.stringify(prepared.payload)).digest('hex'),state:'prepared',created_at:new Date().toISOString()};
            saveSubmission(record);
            const current = shared.read(body.workspace_id,body.pane_id);
            shared.write(body.workspace_id,body.pane_id,{...current,ordinary_submission_id:receiptId,submission_pending:receiptId});
            for (const file of [path.join(runtimeDirectory,'shared-chats',`${body.workspace_id}.${body.pane_id}.json`),path.join(runtimeDirectory,'shared-chats')]) {
              const fd = fs.openSync(file, 'r');
              try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
            }
            record.state = 'dispatching'; saveSubmission(record);
            // dispatchExact owns the pane/session locks. Do not take the legacy
            // session lock or carry the request's pane lock into that adapter.
            shared.locks.delete(paneLock); paneLock = undefined;
            const data = await submissions.dispatchExact({...args,payload:record.payload,submission_id:receiptId,preservePending:true,idempotency_key:prepared.caps.idempotent_submit ? receiptId : undefined,onAccepted: data => {
               record.run_id = data.run_id; record.state = 'accepted'; saveSubmission(record);
               // Host-only observer receives the durable exact receipt, never UI
               // identity assertions. A grant setup failure cannot replay a run.
               try { onNormalAccepted?.(structuredClone(record)); } catch {}
               observeStatus({workspace_id:record.workspace_id,profile_id:record.recipient.profile_id,session_id:record.recipient.session_id,run_id:record.run_id},data);
             }}, allowConcurrent);
            return reply(res,202,{...data,...publicReceipt(record)});
          } catch (error) {
            if (!record) throw error;
            record.state = error.ambiguous || record.run_id ? 'submission_unknown' : 'denied';
            try { saveSubmission(record); } catch { record.state = 'submission_unknown'; }
            if (record.state === 'denied') {
              const current = shared.read(body.workspace_id,body.pane_id);
              if (current?.submission_pending === receiptId) shared.write(body.workspace_id,body.pane_id,{...current,submission_pending:undefined});
            }
            return reply(res,409,{error:record.state === 'submission_unknown' ? 'Submission outcome is unknown. Inspect submission_status; do not resend.' : 'Submission was not dispatched or was rejected.',...publicReceipt(record)});
          }
        }
        const lock = `session:${profileId}:${body.session_id}`;
        if(shared.locks.has(lock)) return reply(res,409,{error:'A message is already starting in this conversation.'});
        if(body.pane_id) {
          const current = shared.read(body.workspace_id,body.pane_id);
          if(current?.run) return reply(res,409,{error:'This conversation is already running on another device.'});
          if(shared.hasActive(profileId,body.session_id,body.workspace_id,body.pane_id)) return reply(res,409,{error:'This conversation is already running in another pane.'});
        }
        shared.locks.add(lock);
        try {
        // Older Hermes Runs implementations persist sessions but do not reload
        // their transcripts automatically. Supply bounded conversational history
        // from the authenticated session API (never from untrusted client roles).
        let conversation_history = [];
        try {
          const transcript = await upstream(`/api/sessions/${body.session_id}/messages`);
          const rows = (transcript.data || []).filter(m => ['user', 'assistant'].includes(m.role) && !m.tool_calls?.length && typeof m.content === 'string' && m.content.trim());
          let size = 0;
          for (const m of rows.slice(-80).reverse()) {
            const content = m.content.slice(0, 16000);
            if (size + content.length > 120000) break;
            conversation_history.unshift({ role: m.role, content });
            size += content.length;
          }
          while (conversation_history.length && conversation_history[0].role !== 'user') conversation_history.shift();
        } catch (error) { if (error.status !== 404) throw error; }
        if (body.pane_id) {
          const bound = shared.read(body.workspace_id, body.pane_id);
          if (bound && !conversation_history.length && typeof bound.fork_preface === 'string' && bound.fork_preface.trim()) conversation_history = [{ role: 'user', content: bound.fork_preface.slice(0, 16000) }];
          else if (bound?.fork_preface && conversation_history.length) shared.write(body.workspace_id, body.pane_id, { ...bound, fork_preface: undefined });
        }
        let context = '';
        if (body.workspace_id && workspaceContext) {
          try { context = workspaceContext(body.workspace_id); }
          catch { return reply(res, 409, { error: 'Workspace has not synced yet. Wait for workspace connection and retry.' }); }
        }
        const data = await upstream('/v1/runs', { input: body.input.trim(), session_id: body.session_id, instructions: instructions + context, conversation_history });
        if(body.pane_id) {
           const current = shared.read(body.workspace_id,body.pane_id);
          shared.write(body.workspace_id,body.pane_id,{...current,run:data.run_id,messages:[...current.messages,{role:'user',text:body.input.trim()}].slice(-100)});
        }
        return reply(res, 202, { run_id: data.run_id, status: data.status });
        } finally {shared.locks.delete(lock);}
      }
      if (!['status', 'stop', 'approval', 'steer'].includes(body.action) || !runPattern.test(body.run_id || '')) return reply(res, 400, { error: 'Invalid agent action.' });
      const controlChat = chatFor(profile);
      if (controlChat) return controlChat.control(reply, res, { body, profile, shared, workspaceContext });
      const runPath = `/v1/runs/${body.run_id}`;
      const run = await upstream(runPath);
      // Never let Orbit operate on another dashboard's sessions/runs.
      if (run.session_id !== body.session_id) return reply(res, 404, { error: 'Run not found in this Orbit conversation.' });
      if(body.action==='status'&&body.pane_id)observeStatus({workspace_id:body.workspace_id,profile_id:profileId,session_id:body.session_id,run_id:body.run_id},run);
      if (body.action === 'steer') {
        if (typeof body.input !== 'string' || !body.input.trim() || body.input.length > 100000) return reply(res, 400, { error: 'Guidance must contain 1–100,000 characters.' });
        const data = await upstream(`${runPath}/steer`, { input: body.input.trim() });
        return reply(res, 200, { accepted: data.accepted === true });
      }
      if (body.action === 'stop') {
        await upstream(`${runPath}/stop`, {});
        return reply(res, 200, { status: 'stopping' });
      }
      if (body.action === 'approval') {
        if (!['once', 'deny'].includes(body.choice)) return reply(res, 400, { error: 'Only allow-once or deny is supported.' });
        const data = await upstream(`${runPath}/approval`, { choice: body.choice });
        return reply(res, 200, { status: 'running', resolved: data.resolved });
      }
      let approvals = [];
      if (run.status === 'waiting_for_approval') {
        const pending = await upstream(`/v1/approvals/pending?session_id=${encodeURIComponent(body.run_id)}`);
        approvals = (pending.approvals || []).map(a => ({ command: String(a.command || a.description || a.tool_name || 'Tool execution requires approval').slice(0, 4000), reason: String(a.reason || '').slice(0, 1000) }));
      }
      if(body.pane_id && ['completed','failed','cancelled','interrupted'].includes(run.status)) {
        const current = shared.read(body.workspace_id,body.pane_id);
        if(current?.run === body.run_id && current.session === body.session_id && current.profile_id === profileId) shared.write(body.workspace_id,body.pane_id,{...current,run:undefined,messages:[...current.messages,{role:'assistant',text:run.output || `Run ${run.status}.`}].slice(-100)});
      }
      const promptTokens = Number(run?.usage?.prompt_tokens);
      const usage = Number.isFinite(promptTokens) && promptTokens >= 0 && promptTokens < 1e12 ? { prompt_tokens: Math.round(promptTokens) } : undefined;
      if (usage && body.pane_id) {
        try {
          const current = shared.read(body.workspace_id, body.pane_id);
          const estimated = measureContext({ messages: current?.messages || [] }).estimated;
          const ratio = calibrate(estimated, usage.prompt_tokens);
          const key = tokenRatioKey(profile);
          if (ratio && key) writeTokenRatio(runtimeDirectory, key, ratio);
        } catch { /* Calibration must not fail a status read. */ }
      }
      return reply(res, 200, { run_id: run.run_id, status: run.status, output: typeof run.output === 'string' ? run.output : '', error: run.error ? 'Hermes reported a run failure. Try again or check the Hermes dashboard.' : undefined, last_event: run.last_event, approvals, ...(usage ? { usage } : {}) });
    } catch (error) {
      if (res.headersSent) { res.end(); return; }
      if (!error.status && ['stale_resource','busy','permission_denied','invalid_request','limit_exceeded','unavailable'].includes(error.code)) return reply(res,error.code === 'invalid_request' ? 400 : error.code === 'unavailable' ? 503 : 409,{error:error.code === 'stale_resource' ? 'The original Hermes configuration or binding changed. Restore it before inspecting this submission.' : 'Submission cannot proceed; inspect the original receipt before retrying.',code:error.code});
      return reply(res, error.status || 502, { error: error.status ? error.message : 'Cannot reach Hermes right now. Your run may still be active; retry status before sending again.' });
    } finally {
      if(paneLock) shared.locks.delete(paneLock);
    }
  };
  const submissions = createHermesSubmission({ configuration, shared, locks: shared.locks, upstreamFor, validatePane });
  const resourceFailure=code=>{throw Object.assign(Error(code),{code});};
  function resourceRecipient({workspace_id,pane_id}) {
    try{validatePane({workspace_id,pane_id});}catch(error){resourceFailure(error.status===404?'resource_gone':'unavailable');}
    const linked=shared.read(workspace_id,pane_id),profile=configuration?.get(linked?.profile_id);
    if(!linked||!profile)resourceFailure('unavailable');
    return {pane_id,profile_id:profile.id,session_id:linked.session,binding_revision:linked.binding_revision,
      config_generation:createHash('sha256').update(`${profile.id}\0${profile.apiUrl || ''}\0${profile.apiKey || ''}`).digest('hex'),
      destination:new URL(profile.apiUrl).origin,profile_label:profile.label??profile.id};
  }
  agent.resourceBindings={
    current:resourceRecipient,
    retirementReason(workspace_id,normal){
      let current;
      try{current=resourceRecipient({workspace_id,pane_id:normal.recipient.pane_id});}
      catch(error){if(error.code==='resource_gone')return 'resource_gone';throw error;}
      if(['profile_id','session_id','binding_revision','config_generation'].some(key=>current[key]!==normal.recipient[key]))return 'binding_changed';
      if(!normal.run_id)return null;
      const linked=shared.read(workspace_id,current.pane_id);
      if(linked?.ordinary_submission_id&&linked.ordinary_submission_id!==normal.receipt_id)return 'superseded';
      // Only a reconciled accepted receipt with BOTH activity markers cleared
      // proves completion. Unknown/preparing submissions must retain their fence.
      if(linked?.ordinary_submission_id===normal.receipt_id&&!linked.run&&!linked.submission_pending&&readSubmission({workspace_id,pane_id:current.pane_id},linked)?.state==='accepted')return 'completed';
      return null;
    },
    list(workspace_id){
      const result=[];const walk=node=>{if(node.type==='pane'){if(node.pane.kind==='agent'){try{result.push(resourceRecipient({workspace_id,pane_id:node.pane.id}));}catch{}}}else{walk(node.first);walk(node.second);}};
      for(const monitor of workspaceRead(workspace_id).state.monitors)walk(monitor.layout);return result;
    },
    authorize(workspace_id,normal){
      const current=resourceRecipient({workspace_id,pane_id:normal.recipient.pane_id});
      for(const key of ['profile_id','session_id','binding_revision','config_generation'])if(current[key]!==normal.recipient[key])resourceFailure('stale_resource');
      if(!normal.run_id||!normal.receipt_id)resourceFailure('permission_denied');
      const record=readSubmission({workspace_id,pane_id:current.pane_id});
      if(!record||record.state!=='accepted'||record.receipt_id!==normal.receipt_id||record.run_id!==normal.run_id||record.payload_hash!==normal.payload_hash||createHash('sha256').update(JSON.stringify(record.payload)).digest('hex')!==normal.payload_hash)resourceFailure('permission_denied');
      for(const key of ['profile_id','session_id','binding_revision','config_generation'])if(record.recipient[key]!==current[key])resourceFailure('stale_resource');
      return current;
    },
    async validateRun(workspace_id,normal){
      const current=this.authorize(workspace_id,normal),profile=configuration.get(current.profile_id);
      const run=await upstreamFor(profile,`/v1/runs/${normal.run_id}`);
      this.authorize(workspace_id,normal);
      if(run.run_id!==normal.run_id||run.session_id!==current.session_id)resourceFailure('permission_denied');
      if(['completed','failed','cancelled','interrupted'].includes(run.status))throw Object.assign(Error('permission_denied'),{code:'permission_denied',channel_retirement:'completed'});
      if(!['queued','running','waiting_for_approval'].includes(run.status))resourceFailure('permission_denied');
    },
  };
  // Read-only access to the same profile catalog the agent-chat provider dropdown uses.
  agent.profileCatalog = () => configuration;
  // Grok Bots app group rooms reuse the same gateway chat surfaces as the shared room.
  agent.gatewayChats = () => chats;
  // Loopback collab-board API (server/collab-board.mjs): same Collab engine, called in-process.
  agent.collabOperate = body => new Promise((resolve, reject) => collab.handle((_res, status, obj) => (status >= 400 ? reject(Object.assign(new Error(obj?.error || 'Collab request failed.'), { status })) : resolve(obj)), {}, body));
  return agent;
}
